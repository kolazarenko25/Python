# practical_07_task_2_2.py

"""CRUD: Update та Delete для блогу."""


from datetime import datetime

from flask import Flask, request, render_template_string, redirect, url_for, flash, abort


app = Flask(__name__)

app.secret_key = "blog-secret-key"

TITLE_MAX = 200
AUTHOR_MAX = 100
CONTENT_MIN = 10


# --- HTML-шаблони ---

LIST_TEMPLATE = """
<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><title>Блог</title></head>
<body>
    <h1>Публікації</h1>
    {% with messages = get_flashed_messages(with_categories=true) %}
      {% for category, message in messages %}
        <div style="color: {{ 'green' if category == 'success' else 'red' }};">{{ message }}</div>
      {% endfor %}
    {% endwith %}
    <a href="{{ url_for('post_create') }}">+ Нова публікація</a>
    <hr>
    {% for post in posts %}
    <article>
        <h2><a href="{{ url_for('post_detail', post_id=post.id) }}">{{ post.title }}</a></h2>
        <small>{{ post.author }} | {{ post.created_at }}</small>
    </article>
    <hr>
    {% else %}
    <p>Публікацій поки немає.</p>
    {% endfor %}
</body>
</html>
"""


DETAIL_TEMPLATE = """
<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><title>{{ post.title }}</title></head>
<body>
    {% with messages = get_flashed_messages(with_categories=true) %}
      {% for category, message in messages %}
        <div style="color: green;">{{ message }}</div>
      {% endfor %}
    {% endwith %}
    <h1>{{ post.title }}</h1>
    <small>Автор: {{ post.author }} | Створено: {{ post.created_at }}
        {% if post.updated_at %}| Оновлено: {{ post.updated_at }}{% endif %}</small>
    <p>{{ post.content }}</p>
    <a href="{{ url_for('post_edit', post_id=post.id) }}">Редагувати</a> |
    <a href="{{ url_for('post_delete', post_id=post.id) }}" style="color: red;">Видалити</a> |
    <a href="{{ url_for('post_list') }}">← До списку</a>
</body>
</html>
"""


FORM_TEMPLATE = """
<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><title>{{ form_title }}</title></head>
<body>
    <h1>{{ form_title }}</h1>
    {% for error in errors %}
        <div style="color: red;">{{ error }}</div>
    {% endfor %}
    <form method="POST">
        <label>Заголовок:</label><br>
        <input type="text" name="title" value="{{ post.title if post else '' }}"
               required style="width:400px;"><br><br>
        <label>Автор:</label><br>
        <input type="text" name="author" value="{{ post.author if post else '' }}"
               required><br><br>
        <label>Зміст:</label><br>
        <textarea name="content" rows="10" cols="50"
                  required>{{ post.content if post else '' }}</textarea><br><br>
        <button type="submit">{{ button_text }}</button>
        <a href="{{ url_for('post_detail', post_id=post_id) if post_id else url_for('post_list') }}">Скасувати</a>
    </form>
</body>
</html>
"""


DELETE_CONFIRM_TEMPLATE = """

<!DOCTYPE html>

<html>

<head><title>Видалення</title></head>

<body>

    <h1>Підтвердження видалення</h1>

    <p>Ви дійсно бажаєте видалити публікацію "<strong>{{ post.title }}</strong>"?</p>

    <form method="POST">

        <button type="submit" style="color: red;">Так, видалити</button>

        <a href="{{ url_for('post_detail', post_id=post.id) }}">Скасувати</a>

    </form>

</body>

</html>

"""


NOT_FOUND_TEMPLATE = """
<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><title>Не знайдено</title></head>
<body>
    <h1>Публікацію не знайдено</h1>
    <p>Можливо, її було видалено або адреса введена неправильно.</p>
    <a href="{{ url_for('post_list') }}">← До списку публікацій</a>
</body>
</html>
"""


# --- Допоміжні функції ---

def find_post(post_id):
    """Повернути публікацію за id або None."""
    return next((p for p in posts_db if p["id"] == post_id), None)


def read_post_form():
    """Зчитати дані HTML-форми з обрізанням пробілів."""
    return {
        "title": request.form.get("title", "").strip(),
        "author": request.form.get("author", "").strip(),
        "content": request.form.get("content", "").strip(),
    }


def validate_post(data):
    """Повернути список помилок валідації (порожній список — дані коректні)."""
    errors = []
    if not data["title"]:
        errors.append("Заголовок не може бути порожнім")
    elif len(data["title"]) > TITLE_MAX:
        errors.append(f"Заголовок має бути не довшим за {TITLE_MAX} символів")

    if not data["author"]:
        errors.append("Вкажіть автора публікації")
    elif len(data["author"]) > AUTHOR_MAX:
        errors.append(f"Ім'я автора має бути не довшим за {AUTHOR_MAX} символів")

    if not data["content"]:
        errors.append("Зміст не може бути порожнім")
    elif len(data["content"]) < CONTENT_MIN:
        errors.append(f"Зміст має містити щонайменше {CONTENT_MIN} символів")
    return errors


# --- Обробка помилок ---

@app.errorhandler(404)
def page_not_found(error):
    """Коректна сторінка для неіснуючих записів (abort(404))."""
    return render_template_string(NOT_FOUND_TEMPLATE), 404


# --- Маршрути списку та деталей (спрощена версія з завдання 2.1) ---

@app.route("/posts")
def post_list():
    """READ: список публікацій."""
    ordered = sorted(posts_db, key=lambda p: p["id"], reverse=True)
    return render_template_string(LIST_TEMPLATE, posts=ordered)


@app.route("/posts/<int:post_id>")
def post_detail(post_id):
    """READ: деталі публікації."""
    post = find_post(post_id)
    if post is None:
        abort(404)
    return render_template_string(DETAIL_TEMPLATE, post=post)


@app.route("/posts/create", methods=["GET", "POST"])
def post_create():
    """CREATE: створення публікації (використовується для перевірки форм)."""
    global next_id

    form_data = {"title": "", "author": "", "content": ""}
    errors = []
    if request.method == "POST":
        form_data = read_post_form()
        errors = validate_post(form_data)
        if not errors:
            new_post = {"id": next_id, **form_data,
                        "created_at": datetime.now().strftime("%Y-%m-%d %H:%M"),
                        "updated_at": None}
            posts_db.append(new_post)
            next_id += 1
            flash("Публікацію створено", "success")
            return redirect(url_for("post_detail", post_id=new_post["id"]))

    return render_template_string(FORM_TEMPLATE, form_title="Нова публікація",
                                  button_text="Створити", post=form_data,
                                  errors=errors, post_id=None)


# --- UPDATE та DELETE ---

@app.route("/posts/<int:post_id>/edit", methods=["GET", "POST"])
def post_edit(post_id):
    """UPDATE: редагування публікації."""
    post = find_post(post_id)
    if post is None:
        abort(404)

    if request.method == "POST":
        form_data = read_post_form()
        errors = validate_post(form_data)
        if errors:
            # Повторно показуємо форму з уже введеними даними
            return render_template_string(FORM_TEMPLATE, form_title="Редагування публікації",
                                          button_text="Зберегти зміни", post=form_data,
                                          errors=errors, post_id=post_id)

        post.update(form_data)
        post["updated_at"] = datetime.now().strftime("%Y-%m-%d %H:%M")
        flash("Публікацію успішно оновлено", "success")
        return redirect(url_for("post_detail", post_id=post_id))

    # GET: форма з поточними даними
    return render_template_string(FORM_TEMPLATE, form_title="Редагування публікації",
                                  button_text="Зберегти зміни", post=post,
                                  errors=[], post_id=post_id)


@app.route("/posts/<int:post_id>/delete", methods=["GET", "POST"])
def post_delete(post_id):
    """DELETE: видалення публікації з підтвердженням."""
    post = find_post(post_id)
    if post is None:
        abort(404)

    if request.method == "POST":
        posts_db.remove(post)
        flash(f'Публікацію "{post["title"]}" видалено', "success")
        return redirect(url_for("post_list"))

    # GET: сторінка підтвердження (нічого не видаляємо без POST)
    return render_template_string(DELETE_CONFIRM_TEMPLATE, post=post)


# Тимчасове сховище

posts_db = [
    {"id": 1, "title": "Перша публікація", "content": "Зміст першої публікації блогу.",
     "author": "Іван", "created_at": "2025-01-15", "updated_at": None},
    {"id": 2, "title": "Друга публікація", "content": "Зміст другої публікації блогу.",
     "author": "Марія", "created_at": "2025-01-20", "updated_at": None},
]
next_id = 3


if __name__ == "__main__":
    app.run(debug=True, port=5004)
