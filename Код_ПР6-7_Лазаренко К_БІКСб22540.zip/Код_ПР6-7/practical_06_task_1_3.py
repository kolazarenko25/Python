# practical_06_task_1_3.py

"""Cookies та sessions у Flask."""


from datetime import timedelta

from flask import (Flask, request, make_response, session, redirect,
                   url_for, jsonify, abort, render_template_string)


app = Flask(__name__)

# Не екранувати кирилицю в JSON (\uXXXX), щоб відповіді були читабельні
app.json.ensure_ascii = False

app.secret_key = "super-secret-key-for-session"  # для підпису сесій
app.permanent_session_lifetime = timedelta(days=7)  # час життя постійної сесії

COOKIE_MAX_AGE = 30 * 24 * 60 * 60  # 30 днів у секундах
ALLOWED_THEMES = {"light", "dark"}
ALLOWED_LANGUAGES = {"uk", "en"}

LOGIN_TEMPLATE = """
<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><title>Вхід</title></head>
<body>
    <h1>Вхід (імітація авторизації)</h1>
    <form method="POST" action="{{ url_for('login') }}">
        <label>Ім'я користувача: <input type="text" name="username" required></label>
        <button type="submit">Увійти</button>
    </form>
</body>
</html>
"""


def set_preference_cookie(response, key, value):
    """Записати cookie-уподобання з max_age, httponly і samesite."""
    response.set_cookie(
        key,
        value,
        max_age=COOKIE_MAX_AGE,   # браузер зберігатиме cookie 30 днів
        httponly=True,           # недоступний для JavaScript (захист від XSS-крадіжки)
        samesite="Lax",          # не надсилається у сторонніх запитах (захист від CSRF)
    )
    return response


# --- Робота з Cookies ---


@app.route("/set-theme/<theme>")
def set_theme(theme):
    """Встановити тему через cookie."""
    if theme not in ALLOWED_THEMES:
        return jsonify({"error": "Дозволені теми: light, dark"}), 400

    response = make_response(jsonify({"message": "Тему збережено", "theme": theme}))
    return set_preference_cookie(response, "theme", theme)


@app.route("/get-theme")
def get_theme():
    """Прочитати тему з cookie, за замовчуванням 'light'."""
    theme = request.cookies.get("theme", "light")
    return jsonify({"theme": theme})


@app.route("/set-language/<lang>")
def set_language(lang):
    """Встановити мову через cookie."""
    if lang not in ALLOWED_LANGUAGES:
        return jsonify({"error": "Дозволені мови: uk, en"}), 400

    response = make_response(jsonify({"message": "Мову збережено", "language": lang}))
    return set_preference_cookie(response, "language", lang)


@app.route("/preferences")
def preferences():
    """Показати всі cookies, що надійшли з браузера, як JSON."""
    return jsonify({"cookies": dict(request.cookies)})


# --- Робота з Sessions ---


@app.route("/cart/add/<int:product_id>")
def add_to_cart(product_id):
    """Додати товар до кошика (session)."""
    if product_id not in products_db:
        abort(404)

    session.permanent = True
    cart = session.get("cart", [])
    cart.append(product_id)
    session["cart"] = cart  # присвоєння повторно позначає session як змінену

    return jsonify({"message": "Товар додано", "cart": cart})


@app.route("/cart")
def view_cart():
    """Переглянути кошик: товари з кількістю, сумою та загальною вартістю."""
    cart_ids = session.get("cart", [])

    quantities = {}
    for product_id in cart_ids:
        quantities[product_id] = quantities.get(product_id, 0) + 1

    items = []
    total = 0
    for product_id, quantity in quantities.items():
        product = products_db.get(product_id)
        if product is None:
            continue
        subtotal = product["price"] * quantity
        total += subtotal
        items.append({
            "product_id": product_id,
            "name": product["name"],
            "price": product["price"],
            "quantity": quantity,
            "subtotal": subtotal,
        })

    return jsonify({"count": len(cart_ids), "items": items, "total": total})


@app.route("/cart/clear")
def clear_cart():
    """Очистити кошик."""
    session.pop("cart", None)
    return jsonify({"message": "Кошик очищено"})


@app.route("/login", methods=["GET", "POST"])
def login():
    """GET — форма входу; POST — зберегти ім'я користувача у session."""
    if request.method == "GET":
        return render_template_string(LOGIN_TEMPLATE)

    # Підтримуємо і HTML-форму, і JSON-запит
    data = request.get_json(silent=True) or request.form
    username = (data.get("username") or "").strip()
    if not username:
        return jsonify({"error": "Вкажіть username"}), 400

    session.permanent = True
    session["username"] = username
    return redirect(url_for("profile"))


@app.route("/logout")
def logout():
    """Вихід — видалити username з session."""
    session.pop("username", None)
    return redirect(url_for("login"))


@app.route("/profile")
def profile():
    """Профіль користувача — доступний лише після входу."""
    username = session.get("username")
    if not username:
        return redirect(url_for("login"))  # неавторизований користувач

    return jsonify({
        "username": username,
        "cart_size": len(session.get("cart", [])),
    })


@app.route("/demo/difference")
def difference():
    """Пояснення різниці між cookies (клієнтські) та sessions (серверні)."""
    return jsonify({
        "cookies": {
            "де_зберігаються": "у браузері користувача",
            "коли_надсилаються": "з кожним HTTP-запитом до відповідного домену",
            "приклади_в_роботі": ["theme", "language"],
            "ризики": "користувач може переглянути та змінити їх вручну, "
                      "тому не зберігайте в них чутливі дані",
        },
        "sessions": {
            "де_зберігаються": "у Flask за замовчуванням — у cookie 'session', що підписаний "
                               "secret_key (вміст можна прочитати, але не підробити); "
                               "для повністю серверного сховища використовують Flask-Session",
            "приклади_в_роботі": ["cart", "username"],
            "ризики": "зміну даних неможливо непомітно підробити, але без HTTPS "
                      "cookie може бути перехоплений",
        },
    })


# Тимчасова "база" товарів

products_db = {
    1: {"name": "Ноутбук", "price": 25000},
    2: {"name": "Смартфон", "price": 12000},
    3: {"name": "Навушники", "price": 2000},
}


if __name__ == "__main__":
    app.run(debug=True, port=5002)
