# practical_06_task_1_2.py

"""Views/контролери для обробки запитів у Flask."""


from flask import Flask, request, jsonify, abort
from functools import wraps


app = Flask(__name__)

# Не екранувати кирилицю в JSON (\uXXXX), щоб відповіді були читабельні
app.json.ensure_ascii = False


def validate_json(required_fields):
    """Декоратор для валідації JSON-запитів."""
    def decorator(f):
        @wraps(f)
        def wrapper(*args, **kwargs):
            data = request.get_json(silent=True)
            if data is None:
                return jsonify({"error": "Очікується JSON"}), 400
            missing = [field for field in required_fields if field not in data]
            if missing:
                return jsonify({
                    "error": f"Відсутні поля: {', '.join(missing)}"
                }), 400
            return f(*args, **kwargs)
        return wrapper
    return decorator


# --- Допоміжні функції ---

def error_response(message, status, details=None):
    """Уніфікована JSON-відповідь з помилкою."""
    body = {"error": message}
    if details:
        body["details"] = details
    return jsonify(body), status


def _is_number(value):
    """Перевірити, що значення є числом (bool не вважаємо числом)."""
    return isinstance(value, (int, float)) and not isinstance(value, bool)


def validate_item_data(data):
    """Перевірити значення полів елемента.

    Повертає кортеж (очищені_дані, список_помилок).
    """
    if not isinstance(data, dict):
        return None, ["Очікується JSON-об'єкт"]

    errors = []
    name = data.get("name")
    price = data.get("price")
    category = data.get("category")

    if not isinstance(name, str) or not name.strip():
        errors.append("Поле 'name' має бути непорожнім рядком")
    if not _is_number(price) or price <= 0:
        errors.append("Поле 'price' має бути числом більшим за 0")
    if not isinstance(category, str) or not category.strip():
        errors.append("Поле 'category' має бути непорожнім рядком")

    if errors:
        return None, errors

    return {
        "name": name.strip(),
        "price": price,
        "category": category.strip(),
    }, []


# --- View-функції ---


@app.route("/api/items", methods=["GET"])
def get_items():
    """GET /api/items — список елементів з фільтрацією.

    Параметри запиту:
        category (str): фільтр за категорією
        min_price (float): мінімальна ціна
        max_price (float): максимальна ціна
        sort (str): поле сортування (name, price)
        order (str): напрямок (asc, desc)
    """
    category = request.args.get("category")
    sort = request.args.get("sort", "name")
    order = request.args.get("order", "asc")

    # Перетворення типів із перевіркою
    try:
        min_price = float(request.args["min_price"]) if "min_price" in request.args else None
        max_price = float(request.args["max_price"]) if "max_price" in request.args else None
    except ValueError:
        return error_response("min_price і max_price мають бути числами", 400)

    if min_price is not None and max_price is not None and min_price > max_price:
        return error_response("min_price не може бути більшим за max_price", 400)

    sort_keys = {
        "name": lambda item: item["name"].lower(),
        "price": lambda item: item["price"],
    }
    if sort not in sort_keys:
        return error_response(f"Некоректне поле сортування: {sort}", 400,
                              {"allowed": list(sort_keys)})
    if order not in ("asc", "desc"):
        return error_response("order має бути 'asc' або 'desc'", 400)

    result = list(items_db.values())

    if category:
        result = [i for i in result if i["category"].lower() == category.lower()]
    if min_price is not None:
        result = [i for i in result if i["price"] >= min_price]
    if max_price is not None:
        result = [i for i in result if i["price"] <= max_price]

    result.sort(key=sort_keys[sort], reverse=(order == "desc"))

    return jsonify({
        "count": len(result),
        "filters": {
            "category": category,
            "min_price": min_price,
            "max_price": max_price,
            "sort": sort,
            "order": order,
        },
        "items": result,
    }), 200


@app.route("/api/items", methods=["POST"])
@validate_json(["name", "price", "category"])
def create_item():
    """POST /api/items — створити елемент з валідацією."""
    global next_id

    cleaned, errors = validate_item_data(request.get_json())
    if errors:
        return error_response("Помилка валідації", 400, errors)

    item = {"id": next_id, **cleaned}
    items_db[next_id] = item
    next_id += 1

    response = jsonify(item)
    response.status_code = 201
    response.headers["Location"] = f"/api/items/{item['id']}"
    return response


@app.route("/api/items/<int:item_id>", methods=["GET"])
def get_item(item_id):
    """GET /api/items/:id — отримати деталі елемента."""
    item = items_db.get(item_id)
    if item is None:
        abort(404)
    return jsonify(item), 200


@app.route("/api/items/<int:item_id>", methods=["PUT"])
@validate_json(["name", "price", "category"])
def update_item(item_id):
    """PUT /api/items/:id — оновити елемент повністю."""
    if item_id not in items_db:
        abort(404)

    cleaned, errors = validate_item_data(request.get_json())
    if errors:
        return error_response("Помилка валідації", 400, errors)

    items_db[item_id] = {"id": item_id, **cleaned}
    return jsonify(items_db[item_id]), 200


@app.route("/api/items/<int:item_id>", methods=["DELETE"])
def delete_item(item_id):
    """DELETE /api/items/:id — видалити елемент."""
    if items_db.pop(item_id, None) is None:
        abort(404)
    return "", 204


# --- Обробка помилок ---


@app.errorhandler(404)
def not_found(error):
    return jsonify({"error": "Ресурс не знайдено"}), 404


@app.errorhandler(400)
def bad_request(error):
    return jsonify({"error": "Некоректний запит"}), 400


@app.errorhandler(405)
def method_not_allowed(error):
    return jsonify({"error": "Метод не дозволено для цього ресурсу"}), 405


# Тимчасова "база даних"

items_db = {
    1: {"id": 1, "name": "Ноутбук", "price": 25000, "category": "електроніка"},
    2: {"id": 2, "name": "Книга Python", "price": 500, "category": "книги"},
    3: {"id": 3, "name": "Навушники", "price": 2000, "category": "електроніка"},
}
next_id = 4


if __name__ == "__main__":
    app.run(debug=True, port=5001)
