# practical_07_task_2_1.py

"""CRUD: Create та Read для блогу."""


import math
from datetime import datetime

from flask import Flask, request, render_template_string, redirect, url_for, flash, abort


app = Flask(__name__)

app.secret_key = "blog-secret-key"  # потрібен для flash() (зберігається в session)

PER_PAGE = 5          # публікацій на одній сторінці списку
TITLE_MAX = 200       # максимальна довжина заголовка
AUTHOR_MAX = 100      # максимальна довжина імені автора
CONTENT_MIN = 10      # мінімальна довжина тексту публікації


# HTML-шаблони

LIST_TEMPLATE = """
<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><title>Блог</title></head>
<body>
    <h1>Публікації</h1>
    {% with messages = get_flashed_messages(with_categories=true) %}
      {% for category, message in messages %}
        <div style="color: {{ 'green' if category == 'success' else 'red' }};">{{ message }}</div>
      {% endfor %}
    {% endwith %}
    <a href="{{ url_for('post_create') }}">+ Нова публікація</a>
    <hr>
    {% for post in posts %}
    <article>
        <h2><a href="{{ url_for('post_detail', post_id=post.id) }}">{{ post.title }}</a></h2>
        <p>{{ post.content[:100] }}{% if post.content|length > 100 %}...{% endif %}</p>
        <small>{{ post.author }} | {{ post.created_at }}</small>
    </article>
    <hr>
    {% else %}
    <p>Публікацій поки немає.</p>
    {% endfor %}
    <nav>
        {% if page > 1 %}<a href="{{ url_for('post_list', page=page - 1) }}">← Попередня</a>{% endif %}
        <span>Сторінка {{ page }} з {{ pages }}</span>
        {% if page < pages %}<a href="{{ url_for('post_list', page=page + 1) }}">Наступна →</a>{% endif %}
    </nav>
</body>
</html>
"""


DETAIL_TEMPLATE = """
<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><title>{{ post.title }}</title></head>
<body>
    {% with messages = get_flashed_messages(with_categories=true) %}
      {% for category, message in messages %}
        <div style="color: green;">{{ message }}</div>
      {% endfor %}
    {% endwith %}
    <h1>{{ post.title }}</h1>
    <small>Автор: {{ post.author }} | Створено: {{ post.created_at }}</small>
    <p>{{ post.content }}</p>
    <a href="{{ url_for('post_list') }}">← До списку</a>
</body>
</html>
"""


FORM_TEMPLATE = """
<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><title>{{ form_title }}</title></head>
<body>
    <h1>{{ form_title }}</h1>
    {% for error in errors %}
        <div style="color: red;">{{ error }}</div>
    {% endfor %}
    <form method="POST">
        <label>Заголовок:</label><br>
        <input type="text" name="title" value="{{ post.title if post else '' }}"
               style="width:400px;"><br><br>
        <label>Автор:</label><br>
        <input type="text" name="author" value="{{ post.author if post else '' }}"><br><br>
        <label>Зміст:</label><br>
        <textarea name="content" rows="10" cols="50">{{ post.content if post else '' }}</textarea><br><br>
        <button type="submit">{{ button_text }}</button>
        <a href="{{ url_for('post_list') }}">Скасувати</a>
    </form>
</body>
</html>
"""


# --- Допоміжні функції ---

def find_post(post_id):
    """Повернути публікацію за id або None."""
    return next((p for p in posts_db if p["id"] == post_id), None)


def read_post_form():
    """Зчитати дані HTML-форми з обрізанням пробілів."""
    return {
        "title": request.form.get("title", "").strip(),
        "author": request.form.get("author", "").strip(),
        "content": request.form.get("content", "").strip(),
    }


def validate_post(data):
    """Повернути список помилок валідації (порожній список — дані коректні)."""
    errors = []
    if not data["title"]:
        errors.append("Заголовок не може бути порожнім")
    elif len(data["title"]) > TITLE_MAX:
        errors.append(f"Заголовок має бути не довшим за {TITLE_MAX} символів")

    if not data["author"]:
        errors.append("Вкажіть автора публікації")
    elif len(data["author"]) > AUTHOR_MAX:
        errors.append(f"Ім'я автора має бути не довшим за {AUTHOR_MAX} символів")

    if not data["content"]:
        errors.append("Зміст не може бути порожнім")
    elif len(data["content"]) < CONTENT_MIN:
        errors.append(f"Зміст має містити щонайменше {CONTENT_MIN} символів")
    return errors


# --- Маршрути ---

@app.route("/posts")
def post_list():
    """READ: список усіх публікацій з пагінацією (?page=1)."""
    page = request.args.get("page", default=1, type=int)
    pages = max(1, math.ceil(len(posts_db) / PER_PAGE))
    if page < 1 or page > pages:
        abort(404)  # такої сторінки немає

    # Найновіші публікації показуємо першими
    ordered = sorted(posts_db, key=lambda p: p["id"], reverse=True)
    start = (page - 1) * PER_PAGE
    items = ordered[start:start + PER_PAGE]

    return render_template_string(LIST_TEMPLATE, posts=items, page=page, pages=pages)


@app.route("/posts/<int:post_id>")
def post_detail(post_id):
    """READ: деталі однієї публікації."""
    post = find_post(post_id)
    if post is None:
        abort(404)
    return render_template_string(DETAIL_TEMPLATE, post=post)


@app.route("/posts/create", methods=["GET", "POST"])
def post_create():
    """CREATE: створення нової публікації."""
    global next_id

    form_data = {"title": "", "author": "", "content": ""}
    errors = []

    if request.method == "POST":
        form_data = read_post_form()
        errors = validate_post(form_data)

        if not errors:
            new_post = {
                "id": next_id,
                **form_data,
                "created_at": datetime.now().strftime("%Y-%m-%d %H:%M"),
            }
            posts_db.append(new_post)
            next_id += 1
            flash("Публікацію успішно створено!", "success")
            return redirect(url_for("post_detail", post_id=new_post["id"]))

    # GET або POST з помилками: показуємо форму (з уже введеними даними)
    return render_template_string(
        FORM_TEMPLATE,
        form_title="Нова публікація",
        button_text="Створити",
        post=form_data,
        errors=errors,
    )


def seed_demo_data():
    """Заповнити блог тестовими публікаціями для демонстрації пагінації."""
    global next_id
    titles = [
        ("Вступ до Flask", "Іван", "2025-03-01"),
        ("Маршрути та конвертери", "Марія", "2025-03-05"),
        ("Робота з формами", "Петро", "2025-03-09"),
        ("Шаблони Jinja2", "Іван", "2025-03-14"),
        ("Сесії та куки", "Марія", "2025-03-20"),
        ("Основи CRUD у вебі", "Петро", "2025-03-27"),
    ]
    for title, author, date_str in titles:
        posts_db.append({
            "id": next_id,
            "title": title,
            "content": f"Короткий опис теми «{title}» для демонстраційного блогу.",
            "author": author,
            "created_at": f"{date_str} 12:00",
        })
        next_id += 1


# Тимчасове сховище

posts_db = []
next_id = 1


if __name__ == "__main__":
    seed_demo_data()  # демонстраційні дані (можна прибрати для порожнього блогу)
    app.run(debug=True, port=5003)
