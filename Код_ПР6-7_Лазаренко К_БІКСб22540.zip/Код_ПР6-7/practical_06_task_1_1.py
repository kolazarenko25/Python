# practical_06_task_1_1.py

"""Маршрутизація Flask: GET, POST, динамічні параметри."""

import math
from datetime import date

from flask import Flask, request, render_template_string, redirect, url_for, abort


app = Flask(__name__)


# Шаблон HTML для демонстрації (базова сторінка з навігацією)

BASE_TEMPLATE = """
<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><title>{{ title }}</title></head>
<body>
    <h1>{{ title }}</h1>
    <nav>
        <a href="{{ url_for('index') }}">Головна</a> |
        <a href="{{ url_for('post_list') }}">Публікації</a> |
        <a href="{{ url_for('post_create') }}">Нова публікація</a> |
        <a href="{{ url_for('search') }}">Пошук</a>
    </nav>
    <hr>
    {{ content | safe }}
</body>
</html>
"""

# Фрагменти вмісту сторінок. Вони рендеряться окремо, тому всі дані,
# які ввів користувач, автоматично екрануються Jinja2 (захист від XSS).

INDEX_TEMPLATE = """
<p>Ласкаво просимо! Це демонстраційний блог на Flask.</p>
<p>Кількість публікацій: {{ total }}</p>
<ul>
    <li><a href="{{ url_for('post_list', page=1, per_page=2) }}">Список з пагінацією</a></li>
    <li><a href="{{ url_for('post_detail', post_id=1) }}">Публікація з id=1</a></li>
    <li><a href="{{ url_for('search', q='Flask') }}">Пошук «Flask»</a></li>
    <li><a href="{{ url_for('archive', year=2025, month=1) }}">Архів за січень 2025</a></li>
    <li><a href="{{ url_for('user_profile', username='Іван') }}">Профіль користувача «Іван»</a></li>
</ul>
"""

POST_LIST_TEMPLATE = """
<ul>
{% for post in posts %}
    <li><a href="{{ url_for('post_detail', post_id=post.id) }}">{{ post.title }}</a>
        — {{ post.author }}, {{ post.created_at }}</li>
{% else %}
    <li>Публікацій немає.</li>
{% endfor %}
</ul>
<p>Сторінка {{ page }} з {{ pages }} (по {{ per_page }} на сторінку)</p>
{% if page > 1 %}
    <a href="{{ url_for('post_list', page=page - 1, per_page=per_page) }}">← Попередня</a>
{% endif %}
{% if page < pages %}
    <a href="{{ url_for('post_list', page=page + 1, per_page=per_page) }}">Наступна →</a>
{% endif %}
"""

POST_DETAIL_TEMPLATE = """
<p><small>Автор: {{ post.author }} | Дата: {{ post.created_at }}</small></p>
<p>{{ post.content }}</p>
<a href="{{ url_for('post_list') }}">← До списку</a>
"""

POST_FORM_TEMPLATE = """
{% for error in errors %}
    <p style="color: red;">{{ error }}</p>
{% endfor %}
<form method="POST" action="{{ url_for('post_create') }}">
    <label>Заголовок: <input type="text" name="title" value="{{ form.title }}"></label><br><br>
    <label>Автор: <input type="text" name="author" value="{{ form.author }}"></label><br><br>
    <label>Зміст:<br>
        <textarea name="content" rows="6" cols="60">{{ form.content }}</textarea>
    </label><br><br>
    <button type="submit">Зберегти</button>
</form>
"""

SEARCH_TEMPLATE = """
<form method="GET" action="{{ url_for('search') }}">
    <input type="text" name="q" value="{{ query }}" placeholder="Пошуковий запит">
    <button type="submit">Знайти</button>
</form>
{% if query %}
    <p>Результати для «{{ query }}»: {{ results | length }}</p>
    <ul>
    {% for post in results %}
        <li><a href="{{ url_for('post_detail', post_id=post.id) }}">{{ post.title }}</a></li>
    {% else %}
        <li>Нічого не знайдено.</li>
    {% endfor %}
    </ul>
{% endif %}
"""

ARCHIVE_TEMPLATE = """
<p>Публікації за період: {{ prefix }}</p>
<ul>
{% for post in items %}
    <li><a href="{{ url_for('post_detail', post_id=post.id) }}">{{ post.title }}</a>
        ({{ post.created_at }})</li>
{% else %}
    <li>За цей період публікацій немає.</li>
{% endfor %}
</ul>
"""

USER_TEMPLATE = """
<p>Публікації користувача: {{ username }}</p>
<ul>
{% for post in items %}
    <li><a href="{{ url_for('post_detail', post_id=post.id) }}">{{ post.title }}</a></li>
{% endfor %}
</ul>
"""


def render_page(title, content_template, **context):
    """Відрендерити вміст сторінки та вставити його у базовий шаблон."""
    content = render_template_string(content_template, **context)
    return render_template_string(BASE_TEMPLATE, title=title, content=content)


def find_post(post_id):
    """Повернути публікацію за id або None."""
    return next((p for p in posts_db if p["id"] == post_id), None)


# Головна сторінка (GET /)

@app.route("/")
def index():
    return render_page("Головна", INDEX_TEMPLATE, total=len(posts_db))


# Список публікацій (GET /posts?page=1&per_page=10)

@app.route("/posts")
def post_list():
    # Параметри пагінації з request.args; type=int повертає значення за замовчуванням,
    # якщо параметр не є числом
    page = request.args.get("page", default=1, type=int)
    per_page = request.args.get("per_page", default=10, type=int)

    # Захист від некоректних значень
    page = max(page, 1)
    per_page = min(max(per_page, 1), 50)

    pages = max(1, math.ceil(len(posts_db) / per_page))
    start = (page - 1) * per_page
    items = posts_db[start:start + per_page]

    return render_page(
        "Публікації",
        POST_LIST_TEMPLATE,
        posts=items,
        page=page,
        per_page=per_page,
        pages=pages,
    )


# Деталі публікації (GET /posts/<int:post_id>)

@app.route("/posts/<int:post_id>")
def post_detail(post_id):
    post = find_post(post_id)
    if post is None:
        abort(404)  # Публікації з таким id немає
    return render_page(post["title"], POST_DETAIL_TEMPLATE, post=post)


# Створення публікації (GET+POST /posts/create)

@app.route("/posts/create", methods=["GET", "POST"])
def post_create():
    global next_id

    form_data = {"title": "", "author": "", "content": ""}
    errors = []

    if request.method == "POST":
        # Дані HTML-форми з request.form
        form_data = {
            "title": request.form.get("title", "").strip(),
            "author": request.form.get("author", "").strip(),
            "content": request.form.get("content", "").strip(),
        }

        if not form_data["title"]:
            errors.append("Заголовок є обов'язковим")
        if not form_data["author"]:
            errors.append("Вкажіть автора")
        if not form_data["content"]:
            errors.append("Зміст не може бути порожнім")

        if not errors:
            new_post = {
                "id": next_id,
                **form_data,
                "created_at": date.today().isoformat(),
            }
            posts_db.append(new_post)
            next_id += 1
            # PRG-патерн: після успішного POST перенаправляємо на сторінку публікації
            return redirect(url_for("post_detail", post_id=new_post["id"]))

    return render_page(
        "Нова публікація",
        POST_FORM_TEMPLATE,
        form=form_data,
        errors=errors,
    )


# Пошук (GET /search?q=query)

@app.route("/search")
def search():
    query = request.args.get("q", "").strip()
    results = []
    if query:
        needle = query.lower()
        results = [
            p for p in posts_db
            if needle in p["title"].lower() or needle in p["content"].lower()
        ]
    return render_page("Пошук", SEARCH_TEMPLATE, query=query, results=results)


# Архів за датою (GET /archive/<int:year>/<int:month>)

@app.route("/archive/<int:year>/<int:month>")
def archive(year, month):
    if not 1 <= month <= 12:
        abort(404)
    prefix = f"{year:04d}-{month:02d}"
    items = [p for p in posts_db if p["created_at"].startswith(prefix)]
    return render_page(f"Архів: {prefix}", ARCHIVE_TEMPLATE, items=items, prefix=prefix)


# Профіль користувача (GET /user/<string:username>)

@app.route("/user/<string:username>")
def user_profile(username):
    items = [p for p in posts_db if p["author"].lower() == username.lower()]
    if not items:
        abort(404)  # Автора з такою назвою немає
    return render_page(
        f"Профіль: {username}",
        USER_TEMPLATE,
        username=username,
        items=items,
    )


# Тимчасове сховище даних

posts_db = [
    {"id": 1, "title": "Вступ до Python", "content": "Python — потужна мова...",
     "author": "Іван", "created_at": "2025-01-15"},
    {"id": 2, "title": "Flask для початківців", "content": "Flask — мікрофреймворк...",
     "author": "Марія", "created_at": "2025-01-20"},
    {"id": 3, "title": "REST API", "content": "REST — архітектурний стиль...",
     "author": "Петро", "created_at": "2025-02-03"},
]
next_id = 4


if __name__ == "__main__":
    app.run(debug=True, port=5000)
