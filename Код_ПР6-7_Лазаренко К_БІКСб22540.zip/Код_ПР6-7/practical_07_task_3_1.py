# practical_07_task_3_1.py

"""REST API для ресурсу 'Студент'."""


import math
import re
from datetime import datetime

from flask import Flask, request, jsonify, abort


app = Flask(__name__)

# Не екранувати кирилицю в JSON (\uXXXX), щоб відповіді були читабельні
app.json.ensure_ascii = False


EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
SORT_FIELDS = ("name", "gpa", "group")
DEFAULT_PER_PAGE = 10
MAX_PER_PAGE = 100

# "База даних" студентів
students_db = {}
next_id = 1


# --- Допоміжні функції ---

def error(message, status, details=None):
    """Уніфікована JSON-відповідь з помилкою."""
    body = {"error": message, "status": status}
    if details:
        body["details"] = details
    return jsonify(body), status


def _is_number(value):
    """Перевірити, що значення є числом (bool не вважаємо числом)."""
    return isinstance(value, (int, float)) and not isinstance(value, bool)


def validate_student(data, partial=False):
    """Валідація даних студента.

    partial=False — усі поля обов'язкові (POST, PUT);
    partial=True  — перевіряються лише передані поля (PATCH).

    Повертає кортеж (очищені_дані, словник_помилок).
    """
    if not isinstance(data, dict):
        return {}, {"body": "Очікується JSON-об'єкт"}

    cleaned = {}
    errors = {}

    def is_required(field):
        return (not partial) or (field in data)

    if is_required("name"):
        name = data.get("name")
        if isinstance(name, str) and name.strip():
            cleaned["name"] = name.strip()
        else:
            errors["name"] = "Обов'язкове непорожнє поле"

    if is_required("group"):
        group = data.get("group")
        if isinstance(group, str) and group.strip():
            cleaned["group"] = group.strip()
        else:
            errors["group"] = "Обов'язкове непорожнє поле"

    if is_required("email"):
        email = data.get("email")
        if isinstance(email, str) and EMAIL_RE.match(email.strip()):
            cleaned["email"] = email.strip().lower()
        else:
            errors["email"] = "Некоректний формат email"

    if is_required("gpa"):
        gpa = data.get("gpa")
        if _is_number(gpa) and 0 <= gpa <= 100:
            cleaned["gpa"] = float(gpa)
        else:
            errors["gpa"] = "GPA має бути числом у діапазоні 0–100"

    if partial and not cleaned and not errors:
        errors["body"] = "Немає жодного поля для оновлення"

    return cleaned, errors


def email_taken(email, exclude_id=None):
    """Чи зайнятий email іншим студентом (exclude_id — поточний студент)."""
    return any(
        s["email"] == email and s["id"] != exclude_id
        for s in students_db.values()
    )


def parse_int_arg(name, default):
    """Прочитати цілочисельний query-параметр; ValueError — якщо це не число."""
    return int(request.args.get(name, default))


# --- REST API ендпоінти ---


@app.route("/api/students", methods=["GET"])
def get_students():
    """GET /api/students — список усіх студентів.

    Query parameters:
        group (str): фільтр за групою
        min_gpa (float): мінімальний середній бал
        sort_by (str): поле сортування (name, gpa, group)
        order (str): asc або desc
        page (int): номер сторінки
        per_page (int): кількість на сторінці (за замовчуванням 10)
    """
    group = request.args.get("group")
    sort_by = request.args.get("sort_by", "name")
    order = request.args.get("order", "asc")

    try:
        page = parse_int_arg("page", 1)
        per_page = parse_int_arg("per_page", DEFAULT_PER_PAGE)
        min_gpa = float(request.args["min_gpa"]) if "min_gpa" in request.args else None
    except ValueError:
        return error("page, per_page та min_gpa мають бути числами", 400)

    if page < 1 or not 1 <= per_page <= MAX_PER_PAGE:
        return error(f"page >= 1, а per_page має бути від 1 до {MAX_PER_PAGE}", 400)
    if sort_by not in SORT_FIELDS:
        return error(f"sort_by має бути одним із: {', '.join(SORT_FIELDS)}", 400)
    if order not in ("asc", "desc"):
        return error("order має бути 'asc' або 'desc'", 400)

    result = list(students_db.values())

    # Фільтрація
    if group:
        result = [s for s in result if s["group"].lower() == group.lower()]
    if min_gpa is not None:
        result = [s for s in result if s["gpa"] >= min_gpa]

    # Сортування
    if sort_by == "name":
        result.sort(key=lambda s: s["name"].lower(), reverse=(order == "desc"))
    else:
        result.sort(key=lambda s: s[sort_by], reverse=(order == "desc"))

    # Пагінація
    total = len(result)
    pages = max(1, math.ceil(total / per_page))
    start = (page - 1) * per_page
    page_items = result[start:start + per_page]

    return jsonify({
        "count": total,
        "page": page,
        "per_page": per_page,
        "pages": pages,
        "students": page_items,
    }), 200


@app.route("/api/students", methods=["POST"])
def create_student():
    """POST /api/students — створити студента.

    JSON body:
        {"name": "str", "group": "str", "email": "str", "gpa": float}
    """
    global next_id

    data = request.get_json(silent=True)
    if data is None:
        return error("Очікується JSON", 400)

    cleaned, errors = validate_student(data)
    if errors:
        return error("Помилка валідації", 400, errors)
    if email_taken(cleaned["email"]):
        return error("Студент з таким email вже існує", 409)

    student = {
        "id": next_id,
        **cleaned,
        "created_at": datetime.now().isoformat(timespec="seconds"),
    }
    students_db[next_id] = student
    next_id += 1

    response = jsonify(student)
    response.status_code = 201
    response.headers["Location"] = f"/api/students/{student['id']}"
    return response


@app.route("/api/students/<int:student_id>", methods=["GET"])
def get_student(student_id):
    """GET /api/students/:id — отримати конкретного студента."""
    student = students_db.get(student_id)
    if student is None:
        abort(404)
    return jsonify(student), 200


@app.route("/api/students/<int:student_id>", methods=["PUT"])
def update_student(student_id):
    """PUT /api/students/:id — повне оновлення студента (усі поля обов'язкові)."""
    student = students_db.get(student_id)
    if student is None:
        abort(404)

    data = request.get_json(silent=True)
    if data is None:
        return error("Очікується JSON", 400)

    cleaned, errors = validate_student(data, partial=False)
    if errors:
        return error("Помилка валідації", 400, errors)
    if email_taken(cleaned["email"], exclude_id=student_id):
        return error("Студент з таким email вже існує", 409)

    student.update(cleaned)
    student["updated_at"] = datetime.now().isoformat(timespec="seconds")
    return jsonify(student), 200


@app.route("/api/students/<int:student_id>", methods=["PATCH"])
def patch_student(student_id):
    """PATCH /api/students/:id — часткове оновлення студента."""
    student = students_db.get(student_id)
    if student is None:
        abort(404)

    data = request.get_json(silent=True)
    if data is None:
        return error("Очікується JSON", 400)

    cleaned, errors = validate_student(data, partial=True)
    if errors:
        return error("Помилка валідації", 400, errors)
    if "email" in cleaned and email_taken(cleaned["email"], exclude_id=student_id):
        return error("Студент з таким email вже існує", 409)

    student.update(cleaned)
    student["updated_at"] = datetime.now().isoformat(timespec="seconds")
    return jsonify(student), 200


@app.route("/api/students/<int:student_id>", methods=["DELETE"])
def delete_student(student_id):
    """DELETE /api/students/:id — видалити студента (204 без тіла)."""
    if students_db.pop(student_id, None) is None:
        abort(404)
    return "", 204


@app.route("/api/students/stats", methods=["GET"])
def students_stats():
    """GET /api/students/stats — статистика по студентах.

    Returns:
        JSON: total, avg_gpa, groups (кількість по групах), top_students
    """
    students = list(students_db.values())
    total = len(students)

    avg_gpa = round(sum(s["gpa"] for s in students) / total, 2) if total else 0.0

    groups = {}
    for s in students:
        groups[s["group"]] = groups.get(s["group"], 0) + 1

    top = sorted(students, key=lambda s: s["gpa"], reverse=True)[:3]
    top_students = [{"id": s["id"], "name": s["name"], "gpa": s["gpa"]} for s in top]

    return jsonify({
        "total": total,
        "avg_gpa": avg_gpa,
        "groups": groups,
        "top_students": top_students,
    }), 200


# --- Обробка помилок ---


@app.errorhandler(404)
def not_found(error):
    return jsonify({"error": "Ресурс не знайдено", "status": 404}), 404


@app.errorhandler(400)
def bad_request(error):
    return jsonify({"error": "Некоректний запит", "status": 400}), 400


@app.errorhandler(405)
def method_not_allowed(error):
    return jsonify({"error": "Метод не дозволено", "status": 405}), 405


@app.errorhandler(422)
def unprocessable(error):
    return jsonify({"error": "Помилка валідації", "status": 422}), 422


if __name__ == "__main__":
    # Заповнити тестовими даними
    test_students = [
        {"name": "Іваненко О.", "group": "КІ-21", "email": "ivan@kpi.ua", "gpa": 85.5},
        {"name": "Петренко М.", "group": "КІ-21", "email": "petro@kpi.ua", "gpa": 92.0},
        {"name": "Сидоренко А.", "group": "КІ-22", "email": "syd@kpi.ua", "gpa": 78.3},
        {"name": "Коваль Л.", "group": "КІ-22", "email": "koval@kpi.ua", "gpa": 95.1},
    ]
    for s in test_students:
        students_db[next_id] = {**s, "id": next_id,
                                "created_at": datetime.now().isoformat(timespec="seconds")}
        next_id += 1

    app.run(debug=True, port=5005)
