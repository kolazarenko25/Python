# practical_07_task_3_2.py

"""REST API: серіалізація, фільтрація, обробка помилок."""

# Примітка: анотації list[str] | None вимагають Python 3.10+

import re
import time
from datetime import datetime
from functools import wraps

from flask import Flask, request, jsonify, g


app = Flask(__name__)

# Не екранувати кирилицю в JSON (\uXXXX), щоб відповіді були читабельні
app.json.ensure_ascii = False


EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
AVAILABLE_FIELDS = ["id", "name", "group", "email", "gpa", "grade_label", "created_at"]
SEARCH_FIELDS = ("name", "email", "group")
SORT_FIELDS = ("id", "name", "gpa", "group")


# --- Серіалізатор ---


class StudentSerializer:
    """Серіалізатор для перетворення даних студента."""

    @staticmethod
    def serialize(student: dict, fields: list[str] | None = None) -> dict:
        """Серіалізувати студента (вибрати потрібні поля)."""
        full = {
            "id": student["id"],
            "name": student["name"],
            "group": student["group"],
            "email": student["email"],
            "gpa": student["gpa"],
            # Додаткове обчислюване поле
            "grade_label": StudentSerializer._grade_label(student["gpa"]),
            # Форматування дати в людський вигляд
            "created_at": StudentSerializer._format_date(student.get("created_at")),
        }

        if fields is None:
            return full

        unknown = [f for f in fields if f not in AVAILABLE_FIELDS]
        if unknown:
            raise ValueError(f"Невідомі поля: {', '.join(unknown)}")
        return {f: full[f] for f in fields}

    @staticmethod
    def deserialize(data: dict) -> tuple[dict | None, dict]:
        """Десеріалізувати вхідні дані з валідацією.

        Повертає кортеж (очищені_дані, словник_помилок).
        """
        if not isinstance(data, dict):
            return None, {"body": "Очікується JSON-об'єкт"}

        cleaned = {}
        errors = {}

        for field in ("name", "group"):
            value = data.get(field)
            if isinstance(value, str) and value.strip():
                cleaned[field] = value.strip()
            else:
                errors[field] = "Обов'язкове непорожнє поле"

        email = data.get("email")
        if isinstance(email, str) and EMAIL_RE.match(email.strip()):
            cleaned["email"] = email.strip().lower()
        else:
            errors["email"] = "Некоректний формат email"

        # Перетворення типів: рядок "85.5" також допустимий
        gpa = data.get("gpa")
        gpa_value = None
        if not isinstance(gpa, bool):
            try:
                gpa_value = float(gpa)
            except (TypeError, ValueError):
                gpa_value = None
        if gpa_value is not None and 0 <= gpa_value <= 100:
            cleaned["gpa"] = round(gpa_value, 2)
        else:
            errors["gpa"] = "GPA має бути числом у діапазоні 0–100"

        return cleaned, errors

    @staticmethod
    def serialize_list(students: list[dict],
                       fields: list[str] | None = None) -> list[dict]:
        """Серіалізувати список студентів."""
        return [StudentSerializer.serialize(s, fields) for s in students]

    @staticmethod
    def _grade_label(gpa: float) -> str:
        """Словесна оцінка за середнім балом."""
        if gpa >= 90:
            return "відмінно"
        if gpa >= 75:
            return "добре"
        if gpa >= 60:
            return "задовільно"
        return "незадовільно"

    @staticmethod
    def _format_date(iso_value: str | None) -> str | None:
        """Перетворити ISO-дату у формат ДД.ММ.РРРР ГГ:ХХ."""
        if not iso_value:
            return None
        try:
            return datetime.fromisoformat(iso_value).strftime("%d.%m.%Y %H:%M")
        except ValueError:
            return iso_value


# --- Middleware: логування запитів ---


@app.before_request
def log_request():
    """Логувати кожен вхідний запит."""
    g.start_time = time.perf_counter()
    url = request.full_path.rstrip("?")
    print(f"[{datetime.now():%H:%M:%S}] --> {request.method} {url}")


@app.after_request
def add_headers(response):
    """Додати заголовки до кожної відповіді."""
    start = getattr(g, "start_time", None)
    if start is not None:
        elapsed = time.perf_counter() - start
        response.headers["X-Request-Time"] = f"{elapsed:.4f}s"
        print(f"           <-- {response.status_code}")
    response.headers["Access-Control-Allow-Origin"] = "*"
    return response


# --- Декоратор авторизації (імітація) ---


def require_api_key(f):
    """Перевірка API-ключа у заголовку X-API-Key."""
    @wraps(f)
    def wrapper(*args, **kwargs):
        api_key = request.headers.get("X-API-Key")
        if api_key != "secret-api-key-123":
            return jsonify({"error": "Невірний API-ключ", "status": 401}), 401
        return f(*args, **kwargs)
    return wrapper


# --- Централізована обробка помилок ---


class APIError(Exception):
    """Базове виключення API."""

    def __init__(self, message: str, status_code: int = 400, details: dict = None):
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.details = details or {}


@app.errorhandler(APIError)
def handle_api_error(error):
    """Централізована обробка помилок API."""
    response = {
        "error": error.message,
        "status": error.status_code,
        "details": error.details,
        "timestamp": datetime.now().isoformat(timespec="seconds"),
    }
    return jsonify(response), error.status_code


@app.errorhandler(404)
def not_found(error):
    """Ресурс не знайдено — повертаємо JSON через той самий механізм."""
    return handle_api_error(APIError("Ресурс не знайдено", 404))


# --- REST API ендпоінти з серіалізацією ---


@app.route("/api/v2/students", methods=["GET"])
def get_students_v2():
    """GET /api/v2/students — з серіалізацією та вибором полів.

    Query: ?fields=name,group,gpa&search=Іван&sort=gpa&order=desc
    """
    raw_fields = request.args.get("fields")
    search = request.args.get("search", "").strip().lower()
    sort = request.args.get("sort", "id")
    order = request.args.get("order", "asc")

    # Вибір полів: ?fields=name,gpa
    fields = None
    if raw_fields:
        fields = [f.strip() for f in raw_fields.split(",") if f.strip()]
        unknown = [f for f in fields if f not in AVAILABLE_FIELDS]
        if unknown:
            raise APIError(f"Невідомі поля: {', '.join(unknown)}", 400,
                           {"allowed_fields": AVAILABLE_FIELDS})

    if sort not in SORT_FIELDS:
        raise APIError(f"sort має бути одним із: {', '.join(SORT_FIELDS)}", 400)
    if order not in ("asc", "desc"):
        raise APIError("order має бути 'asc' або 'desc'", 400)

    students = list(students_db.values())

    # Текстовий пошук за name, email, group
    if search:
        students = [
            s for s in students
            if any(search in str(s[field]).lower() for field in SEARCH_FIELDS)
        ]

    def sort_key(s):
        value = s[sort]
        return value.lower() if isinstance(value, str) else value

    students.sort(key=sort_key, reverse=(order == "desc"))

    return jsonify({
        "count": len(students),
        "students": StudentSerializer.serialize_list(students, fields),
    }), 200


@app.route("/api/v2/students", methods=["POST"])
@require_api_key
def create_student_v2():
    """POST /api/v2/students — з серіалізацією та авторизацією."""
    global next_id

    data = request.get_json(silent=True)
    if data is None:
        raise APIError("Очікується JSON", 400)

    cleaned, errors = StudentSerializer.deserialize(data)
    if errors:
        raise APIError("Помилка валідації", 400, errors)

    if any(s["email"] == cleaned["email"] for s in students_db.values()):
        raise APIError("Студент з таким email вже існує", 409)

    student = {
        "id": next_id,
        **cleaned,
        "created_at": datetime.now().isoformat(timespec="seconds"),
    }
    students_db[next_id] = student
    next_id += 1

    return jsonify(StudentSerializer.serialize(student)), 201


# Тимчасове сховище

students_db = {}
next_id = 1


if __name__ == "__main__":
    # Тестові дані, щоб одразу можна було перевіряти фільтри та пошук
    seed = [
        {"name": "Іваненко О.", "group": "КІ-21", "email": "ivan@kpi.ua", "gpa": 85.5},
        {"name": "Петренко М.", "group": "КІ-21", "email": "petro@kpi.ua", "gpa": 92.0},
        {"name": "Сидоренко А.", "group": "КІ-22", "email": "syd@kpi.ua", "gpa": 78.3},
        {"name": "Коваль Л.", "group": "КІ-22", "email": "koval@kpi.ua", "gpa": 95.1},
    ]
    for s in seed:
        students_db[next_id] = {**s, "id": next_id,
                                "created_at": datetime.now().isoformat(timespec="seconds")}
        next_id += 1

    app.run(debug=True, port=5006)
