# Практичні роботи №6–7. Маршрутизація, CRUD та REST API (Flask)

Студент: Лазаренко Кирило, група БІКСб22540

## Встановлення

Потрібен Python 3.10 або новіший.

    pip install -r requirements.txt

## Запуск

Кожна програма запускається окремо і працює на власному порту:

| Файл | Завдання | Порт |
|---|---|---|
| practical_06_task_1_1.py | 1.1 Маршрутизація GET/POST | 5000 |
| practical_06_task_1_2.py | 1.2 Контролери та JSON API | 5001 |
| practical_06_task_1_3.py | 1.3 Cookies та sessions | 5002 |
| practical_07_task_2_1.py | 2.1 CRUD: Create та Read | 5003 |
| practical_07_task_2_2.py | 2.2 CRUD: Update та Delete | 5004 |
| practical_07_task_3_1.py | 3.1 REST API «Студент» | 5005 |
| practical_07_task_3_2.py | 3.2 Серіалізація, фільтрація, помилки | 5006 |

Приклад:

    python practical_07_task_3_1.py

Після запуску відкрийте у браузері, наприклад, http://127.0.0.1:5005/api/students

## Авторизація для 3.2

Ендпоінт POST /api/v2/students вимагає заголовок X-API-Key: secret-api-key-123
