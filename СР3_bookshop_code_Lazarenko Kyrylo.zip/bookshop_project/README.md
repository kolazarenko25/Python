# Bookshop: онлайн-замовлення книг (Flask)

Веб-додаток для онлайн-замовлення книг: каталог з пошуком, кошик у сесії,
оформлення замовлень, реєстрація/вхід, CRUD книг для адміністратора,
REST API та тести PyTest.

## Встановлення і запуск

```bash
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt

flask --app bookshop seed          # створює адміністратора admin/admin123 і тестові книги
flask --app bookshop run           # http://127.0.0.1:5000
```

База даних SQLite створюється автоматично у папці `instance/bookshop.db`.
Для іншої СУБД задайте змінну середовища `DATABASE_URL`, наприклад
`postgresql://user:pass@localhost/bookshop`. Змінна `SECRET_KEY` має бути
задана у реальному розгортанні.

## Тестування

```bash
pytest
```

## Структура

- `bookshop/__init__.py` — фабрика застосунку `create_app`, реєстрація blueprint-ів
- `bookshop/models.py` — моделі User, Book, Order, OrderItem
- `bookshop/services.py` — бізнес-логіка (оформлення замовлення, перевірка ISBN)
- `bookshop/validators.py` — валідація даних книги
- `bookshop/auth.py` — поточний користувач, декоратори доступу
- `bookshop/web.py` — маршрути HTML-інтерфейсу
- `bookshop/api.py` — REST API (`/api/...`)
- `bookshop/templates/`, `bookshop/static/` — шаблони Jinja2 і стилі
- `tests/` — тести PyTest
