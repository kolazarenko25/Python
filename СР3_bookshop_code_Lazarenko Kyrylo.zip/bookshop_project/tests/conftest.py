from decimal import Decimal

import pytest

from bookshop import create_app
from bookshop.config import TestConfig
from bookshop.extensions import db
from bookshop.models import Book, User


@pytest.fixture
def app():
    """Окремий застосунок з in-memory SQLite для кожного тесту (ізоляція)."""
    app = create_app(TestConfig)
    with app.app_context():
        yield app
        db.session.remove()
        db.drop_all()


@pytest.fixture
def client(app):
    return app.test_client()


@pytest.fixture
def make_user(app):
    def _make(username="user", email=None, password="pass123", is_admin=False):
        user = User(username=username, email=email or f"{username}@test.com", is_admin=is_admin)
        user.set_password(password)
        db.session.add(user)
        db.session.commit()
        return user

    return _make


@pytest.fixture
def login(client):
    def _login(username="user", password="pass123"):
        return client.post("/api/auth/login", json={"username": username, "password": password})

    return _login


@pytest.fixture
def book(app):
    b = Book(
        title="Кобзар",
        author="Тарас Шевченко",
        isbn="9780000000001",
        price=Decimal("150.00"),
        stock=10,
        description="Тестова книга",
    )
    db.session.add(b)
    db.session.commit()
    return b


@pytest.fixture
def user_client(client, make_user, login):
    make_user()
    login()
    return client


@pytest.fixture
def admin_client(client, make_user, login):
    make_user(username="admin", is_admin=True)
    login("admin")
    return client
