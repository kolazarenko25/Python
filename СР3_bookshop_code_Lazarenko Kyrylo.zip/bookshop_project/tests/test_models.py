from decimal import Decimal

import pytest

from bookshop.models import Order
from bookshop.services import OrderError, book_has_orders, create_order, isbn_taken
from bookshop.validators import ValidationError, parse_book_data


def test_password_is_hashed(make_user):
    user = make_user(password="secret123")
    assert user.password_hash != "secret123"
    assert user.check_password("secret123")
    assert not user.check_password("wrong")


def test_book_to_dict_returns_float_price(book):
    data = book.to_dict()
    assert data["price"] == 150.0
    assert data["title"] == "Кобзар"


def test_create_order_decreases_stock_and_sets_total(make_user, book):
    order = create_order(make_user(), [(book.id, 2)])
    assert order.total == Decimal("300.00")
    assert book.stock == 8
    assert order.items[0].quantity == 2


def test_create_order_rejects_insufficient_stock(make_user, book):
    with pytest.raises(OrderError):
        create_order(make_user(), [(book.id, 99)])
    assert Order.query.count() == 0
    assert book.stock == 10


def test_create_order_rejects_empty_cart(make_user):
    with pytest.raises(OrderError):
        create_order(make_user(), [])


def test_isbn_taken(book):
    assert isbn_taken(book.isbn)
    assert not isbn_taken("0000000000")


def test_book_with_orders_is_protected(make_user, book):
    create_order(make_user(), [(book.id, 1)])
    assert book_has_orders(book.id)


def test_parse_book_reports_invalid_fields():
    with pytest.raises(ValidationError) as exc:
        parse_book_data({"title": "", "author": "A", "isbn": "1", "price": "abc", "stock": "1"})
    assert "title" in exc.value.errors
    assert "price" in exc.value.errors


def test_partial_parse_allows_missing_fields():
    clean = parse_book_data({"price": "99.5"}, partial=True)
    assert clean == {"price": Decimal("99.50")}
