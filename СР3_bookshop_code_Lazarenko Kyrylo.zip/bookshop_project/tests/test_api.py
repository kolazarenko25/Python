NEW_BOOK = {
    "title": "Лісова пісня",
    "author": "Леся Українка",
    "isbn": "9780000000002",
    "price": "120",
    "stock": 5,
}


def test_list_books(client, book):
    resp = client.get("/api/books")
    assert resp.status_code == 200
    assert resp.get_json()[0]["title"] == "Кобзар"


def test_search_books_by_title(client, book):
    found = client.get("/api/books", query_string={"q": "Кобзар"}).get_json()
    missing = client.get("/api/books", query_string={"q": "Неіснуюча"}).get_json()
    assert len(found) == 1
    assert missing == []


def test_get_missing_book_returns_404(client):
    assert client.get("/api/books/999").status_code == 404


def test_anonymous_cannot_create_book(client):
    assert client.post("/api/books", json=NEW_BOOK).status_code == 401


def test_regular_user_cannot_create_book(user_client):
    assert user_client.post("/api/books", json=NEW_BOOK).status_code == 403


def test_admin_creates_book(admin_client):
    resp = admin_client.post("/api/books", json=NEW_BOOK)
    assert resp.status_code == 201
    assert resp.get_json()["price"] == 120.0


def test_duplicate_isbn_returns_409(admin_client, book):
    resp = admin_client.post("/api/books", json={**NEW_BOOK, "isbn": book.isbn})
    assert resp.status_code == 409


def test_invalid_book_returns_422(admin_client):
    resp = admin_client.post("/api/books", json={"title": ""})
    assert resp.status_code == 422
    assert "title" in resp.get_json()["fields"]


def test_update_book_price(admin_client, book):
    resp = admin_client.put(f"/api/books/{book.id}", json={"price": "200"})
    assert resp.status_code == 200
    assert resp.get_json()["price"] == 200.0


def test_delete_book(admin_client, book):
    assert admin_client.delete(f"/api/books/{book.id}").status_code == 204
    assert admin_client.get(f"/api/books/{book.id}").status_code == 404


def test_register_logs_in_user(client):
    resp = client.post(
        "/api/auth/register",
        json={"username": "ivan", "email": "ivan@test.com", "password": "pass123"},
    )
    assert resp.status_code == 201
    assert client.get("/api/auth/me").get_json()["username"] == "ivan"


def test_login_wrong_password(client, make_user, login):
    make_user()
    assert login(password="bad").status_code == 401


def test_logout(user_client):
    assert user_client.post("/api/auth/logout").status_code == 204
    assert user_client.get("/api/auth/me").status_code == 401


def test_create_order_via_api(user_client, book):
    resp = user_client.post("/api/orders", json={"items": [{"book_id": book.id, "quantity": 3}]})
    assert resp.status_code == 201
    data = resp.get_json()
    assert data["total"] == 450.0
    assert data["items"][0]["quantity"] == 3


def test_order_requires_auth(client, book):
    resp = client.post("/api/orders", json={"items": [{"book_id": book.id, "quantity": 1}]})
    assert resp.status_code == 401


def test_order_with_bad_payload_returns_422(user_client):
    assert user_client.post("/api/orders", json={"items": "x"}).status_code == 422


def test_order_insufficient_stock_returns_409(user_client, book):
    resp = user_client.post("/api/orders", json={"items": [{"book_id": book.id, "quantity": 100}]})
    assert resp.status_code == 409


def test_user_sees_only_own_orders(client, make_user, login, book):
    make_user(username="alice")
    make_user(username="bob")
    login("alice")
    order_id = client.post(
        "/api/orders", json={"items": [{"book_id": book.id, "quantity": 1}]}
    ).get_json()["id"]
    login("bob")
    assert client.get("/api/orders").get_json() == []
    assert client.get(f"/api/orders/{order_id}").status_code == 404
