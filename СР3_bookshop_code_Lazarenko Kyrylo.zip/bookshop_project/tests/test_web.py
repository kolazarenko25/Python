from bookshop.extensions import db
from bookshop.models import Book, Order, User


def test_index_lists_books(client, book):
    resp = client.get("/")
    assert resp.status_code == 200
    assert "Кобзар" in resp.get_data(as_text=True)


def test_book_detail_sets_recent_cookie(client, book):
    resp = client.get(f"/books/{book.id}")
    assert resp.status_code == 200
    assert f"recent={book.id}" in resp.headers.get("Set-Cookie", "")


def test_add_to_cart_stores_quantity_in_session(client, book):
    resp = client.post(f"/cart/add/{book.id}")
    assert resp.status_code == 302
    with client.session_transaction() as sess:
        assert sess["cart"][str(book.id)] == 1


def test_cannot_exceed_stock(client, book):
    book.stock = 1
    db.session.commit()
    client.post(f"/cart/add/{book.id}")
    client.post(f"/cart/add/{book.id}")
    with client.session_transaction() as sess:
        assert sess["cart"][str(book.id)] == 1


def test_cart_page_shows_total(client, book):
    client.post(f"/cart/add/{book.id}")
    client.post(f"/cart/add/{book.id}")
    assert "300" in client.get("/cart").get_data(as_text=True)


def test_checkout_requires_login(client, book):
    client.post(f"/cart/add/{book.id}")
    resp = client.post("/checkout")
    assert resp.status_code == 302
    assert "/login" in resp.headers["Location"]


def test_checkout_creates_order_and_clears_cart(user_client, book):
    user_client.post(f"/cart/add/{book.id}")
    resp = user_client.post("/checkout")
    assert resp.status_code == 302
    assert "/orders/" in resp.headers["Location"]
    with user_client.session_transaction() as sess:
        assert "cart" not in sess
    assert Order.query.count() == 1


def test_register_form_creates_user(client):
    resp = client.post(
        "/register",
        data={"username": "olena", "email": "o@test.com", "password": "secret1"},
    )
    assert resp.status_code == 302
    assert User.query.filter_by(username="olena").first() is not None


def test_login_form_sets_session(client, make_user):
    make_user(username="petro")
    resp = client.post("/login", data={"username": "petro", "password": "pass123"})
    assert resp.status_code == 302
    with client.session_transaction() as sess:
        assert "user_id" in sess


def test_admin_can_create_book_via_form(admin_client):
    resp = admin_client.post(
        "/books/new",
        data={
            "title": "Захар Беркут",
            "author": "Іван Франко",
            "isbn": "9780000000003",
            "price": "95",
            "stock": "4",
            "description": "",
        },
    )
    assert resp.status_code == 302
    assert Book.query.filter_by(isbn="9780000000003").first() is not None


def test_regular_user_cannot_open_book_form(user_client):
    assert user_client.get("/books/new").status_code == 403
