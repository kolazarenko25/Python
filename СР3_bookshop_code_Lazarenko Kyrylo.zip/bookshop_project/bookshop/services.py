from decimal import Decimal

from .extensions import db
from .models import Book, Order, OrderItem


class OrderError(Exception):
    """Помилка бізнес-логіки під час оформлення замовлення."""


def isbn_taken(isbn, exclude_id=None):
    query = Book.query.filter_by(isbn=isbn)
    if exclude_id is not None:
        query = query.filter(Book.id != exclude_id)
    return query.first() is not None


def book_has_orders(book_id):
    return OrderItem.query.filter_by(book_id=book_id).first() is not None


def create_order(user, items):
    """Створює замовлення з пар (book_id, quantity).

    Спочатку перевіряються всі позиції і залишки, і лише потім змінюється
    склад, тож часткового списання при помилці не відбувається.
    """
    merged = {}
    for book_id, quantity in items:
        if quantity <= 0:
            raise OrderError("Кількість має бути додатним числом")
        merged[book_id] = merged.get(book_id, 0) + quantity
    if not merged:
        raise OrderError("Кошик порожній")

    books = {}
    for book_id, quantity in merged.items():
        book = db.session.get(Book, book_id)
        if book is None:
            raise OrderError(f"Книгу з id={book_id} не знайдено")
        if book.stock < quantity:
            raise OrderError(
                f"Недостатньо примірників «{book.title}» (доступно: {book.stock})"
            )
        books[book_id] = book

    order = Order(user=user, status="new")
    for book_id, quantity in merged.items():
        book = books[book_id]
        book.stock -= quantity
        order.items.append(
            OrderItem(book=book, quantity=quantity, unit_price=Decimal(str(book.price)))
        )
    order.total = sum(
        (item.unit_price * item.quantity for item in order.items), Decimal("0.00")
    )
    db.session.add(order)
    db.session.commit()
    return order
