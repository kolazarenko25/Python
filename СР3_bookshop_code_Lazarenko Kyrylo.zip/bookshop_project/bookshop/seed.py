from decimal import Decimal

from .extensions import db
from .models import Book, User

SAMPLE_BOOKS = [
    {
        "title": "Кобзар",
        "author": "Тарас Шевченко",
        "isbn": "9786170000011",
        "price": Decimal("180.00"),
        "stock": 15,
        "description": "Збірка поезій Тараса Шевченка.",
    },
    {
        "title": "Лісова пісня",
        "author": "Леся Українка",
        "isbn": "9786170000028",
        "price": Decimal("150.00"),
        "stock": 8,
        "description": "Драма-феєрія у трьох діях.",
    },
    {
        "title": "Тіні забутих предків",
        "author": "Михайло Коцюбинський",
        "isbn": "9786170000035",
        "price": Decimal("210.50"),
        "stock": 5,
        "description": "Повість про гуцульське життя.",
    },
    {
        "title": "Захар Беркут",
        "author": "Іван Франко",
        "isbn": "9786170000042",
        "price": Decimal("130.00"),
        "stock": 0,
        "description": "Історична повість (тимчасово немає в наявності).",
    },
]


def seed_database():
    if not User.query.filter_by(username="admin").first():
        admin = User(username="admin", email="admin@example.com", is_admin=True)
        admin.set_password("admin123")
        db.session.add(admin)

    for data in SAMPLE_BOOKS:
        if not Book.query.filter_by(isbn=data["isbn"]).first():
            db.session.add(Book(**data))

    db.session.commit()
