import os

from flask import Flask

from .config import Config
from .extensions import db


def create_app(config_class=Config):
    """Фабрика застосунку: створює Flask-app із заданою конфігурацією."""
    app = Flask(__name__, instance_relative_config=True)
    app.config.from_object(config_class)
    os.makedirs(app.instance_path, exist_ok=True)

    db.init_app(app)

    from .api import bp as api_bp
    from .web import bp as web_bp

    app.register_blueprint(web_bp)
    app.register_blueprint(api_bp)

    with app.app_context():
        from . import models  # noqa: F401  (реєстрація моделей у metadata)
        db.create_all()

    @app.cli.command("seed")
    def seed_command():
        """Заповнює БД тестовими книгами та адміністратором."""
        from .seed import seed_database

        seed_database()
        print("База даних заповнена тестовими даними (admin / admin123).")

    return app
