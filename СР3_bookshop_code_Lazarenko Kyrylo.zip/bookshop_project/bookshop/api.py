from flask import Blueprint, jsonify, request, session
from sqlalchemy import or_

from .auth import admin_required, current_user, login_required
from .extensions import db
from .models import Book, Order, User
from .services import OrderError, book_has_orders, create_order, isbn_taken
from .validators import ValidationError, parse_book_data

bp = Blueprint("api", __name__, url_prefix="/api")


def _error(message, status, **extra):
    return jsonify(error=message, **extra), status


def _json_body():
    data = request.get_json(silent=True)
    return data if isinstance(data, dict) else None


# ---------- Книги ----------

@bp.route("/books", methods=["GET"])
def list_books():
    q = request.args.get("q", "").strip()
    query = Book.query
    if q:
        like = f"%{q}%"
        query = query.filter(or_(Book.title.ilike(like), Book.author.ilike(like)))
    return jsonify([b.to_dict() for b in query.order_by(Book.id).all()])


@bp.route("/books", methods=["POST"])
@admin_required
def create_book():
    data = _json_body()
    if data is None:
        return _error("Очікується JSON-об'єкт", 400)
    try:
        clean = parse_book_data(data)
    except ValidationError as exc:
        return _error("Помилка валідації", 422, fields=exc.errors)
    if isbn_taken(clean["isbn"]):
        return _error("Книга з таким ISBN вже існує", 409)
    book = Book(**clean)
    db.session.add(book)
    db.session.commit()
    return jsonify(book.to_dict()), 201, {"Location": f"/api/books/{book.id}"}


@bp.route("/books/<int:book_id>", methods=["GET"])
def get_book(book_id):
    book = db.session.get(Book, book_id)
    if book is None:
        return _error("Книгу не знайдено", 404)
    return jsonify(book.to_dict())


@bp.route("/books/<int:book_id>", methods=["PUT", "PATCH"])
@admin_required
def update_book(book_id):
    book = db.session.get(Book, book_id)
    if book is None:
        return _error("Книгу не знайдено", 404)
    data = _json_body()
    if data is None:
        return _error("Очікується JSON-об'єкт", 400)
    try:
        clean = parse_book_data(data, partial=True)
    except ValidationError as exc:
        return _error("Помилка валідації", 422, fields=exc.errors)
    if "isbn" in clean and isbn_taken(clean["isbn"], exclude_id=book.id):
        return _error("Книга з таким ISBN вже існує", 409)
    for field, value in clean.items():
        setattr(book, field, value)
    db.session.commit()
    return jsonify(book.to_dict())


@bp.route("/books/<int:book_id>", methods=["DELETE"])
@admin_required
def delete_book(book_id):
    book = db.session.get(Book, book_id)
    if book is None:
        return _error("Книгу не знайдено", 404)
    if book_has_orders(book.id):
        return _error("Книгу є в замовленнях, видалити не можна", 409)
    db.session.delete(book)
    db.session.commit()
    return "", 204


# ---------- Автентифікація ----------

@bp.route("/auth/register", methods=["POST"])
def api_register():
    data = _json_body()
    if data is None:
        return _error("Очікується JSON-об'єкт", 400)
    username = str(data.get("username", "")).strip()
    email = str(data.get("email", "")).strip()
    password = str(data.get("password", ""))
    if not username or not email or len(password) < 6:
        return _error("Вкажіть username, email і пароль (щонайменше 6 символів)", 422)
    if User.query.filter(or_(User.username == username, User.email == email)).first():
        return _error("Користувач уже існує", 409)
    user = User(username=username, email=email)
    user.set_password(password)
    db.session.add(user)
    db.session.commit()
    session.permanent = True
    session["user_id"] = user.id
    return jsonify(user.to_dict()), 201


@bp.route("/auth/login", methods=["POST"])
def api_login():
    data = _json_body()
    if data is None:
        return _error("Очікується JSON-об'єкт", 400)
    user = User.query.filter_by(username=str(data.get("username", "")).strip()).first()
    if user is None or not user.check_password(str(data.get("password", ""))):
        return _error("Невірний логін або пароль", 401)
    session.permanent = True
    session["user_id"] = user.id
    return jsonify(user.to_dict())


@bp.route("/auth/logout", methods=["POST"])
def api_logout():
    session.pop("user_id", None)
    return "", 204


@bp.route("/auth/me", methods=["GET"])
def api_me():
    user = current_user()
    if user is None:
        return _error("Не автентифіковано", 401)
    return jsonify(user.to_dict())


# ---------- Замовлення ----------

@bp.route("/orders", methods=["GET"])
@login_required
def list_orders():
    user = current_user()
    query = Order.query if user.is_admin else Order.query.filter_by(user_id=user.id)
    return jsonify([o.to_dict() for o in query.order_by(Order.id).all()])


@bp.route("/orders", methods=["POST"])
@login_required
def create_order_api():
    data = _json_body()
    if data is None:
        return _error("Очікується JSON-об'єкт", 400)
    raw_items = data.get("items")
    if not isinstance(raw_items, list) or not raw_items:
        return _error("Поле items має бути непорожнім списком", 422)
    items = []
    for raw in raw_items:
        try:
            items.append((int(raw["book_id"]), int(raw.get("quantity", 1))))
        except (KeyError, TypeError, ValueError, AttributeError):
            return _error("Кожен елемент потребує book_id і quantity (ціле число)", 422)
    try:
        order = create_order(current_user(), items)
    except OrderError as exc:
        return _error(str(exc), 409)
    return jsonify(order.to_dict()), 201, {"Location": f"/api/orders/{order.id}"}


@bp.route("/orders/<int:order_id>", methods=["GET"])
@login_required
def get_order(order_id):
    order = db.session.get(Order, order_id)
    user = current_user()
    if order is None or (order.user_id != user.id and not user.is_admin):
        return _error("Замовлення не знайдено", 404)
    return jsonify(order.to_dict())
