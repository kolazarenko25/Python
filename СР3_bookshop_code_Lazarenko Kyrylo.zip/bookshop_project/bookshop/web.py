from decimal import Decimal

from flask import (
    Blueprint,
    abort,
    flash,
    make_response,
    redirect,
    render_template,
    request,
    session,
    url_for,
)
from sqlalchemy import or_

from .auth import admin_required, current_user, login_required
from .extensions import db
from .models import Book, Order, User
from .services import OrderError, book_has_orders, create_order, isbn_taken
from .validators import ValidationError, parse_book_data

bp = Blueprint("web", __name__)

RECENT_COOKIE = "recent"
RECENT_LIMIT = 5
COOKIE_MAX_AGE = 60 * 60 * 24 * 30  # 30 днів


@bp.app_context_processor
def inject_globals():
    cart = session.get("cart", {})
    return {"user": current_user(), "cart_count": sum(cart.values())}


def _books_by_ids(ids):
    if not ids:
        return []
    found = {b.id: b for b in Book.query.filter(Book.id.in_(ids)).all()}
    return [found[i] for i in ids if i in found]


def _read_recent_ids():
    raw = request.cookies.get(RECENT_COOKIE, "")
    return [int(x) for x in raw.split("-") if x.isdigit()]


# ---------- Каталог і картка книги ----------

@bp.route("/")
def index():
    q = request.args.get("q", "").strip()
    query = Book.query
    if q:
        like = f"%{q}%"
        query = query.filter(or_(Book.title.ilike(like), Book.author.ilike(like)))
    books = query.order_by(Book.title).all()
    return render_template("index.html", books=books, q=q)


@bp.route("/books/<int:book_id>")
def book_detail(book_id):
    book = db.get_or_404(Book, book_id)
    recent = [book_id] + [i for i in _read_recent_ids() if i != book_id]
    recent = recent[:RECENT_LIMIT]
    html = render_template(
        "book_detail.html", book=book, recent_books=_books_by_ids(recent[1:])
    )
    response = make_response(html)
    response.set_cookie(
        RECENT_COOKIE,
        "-".join(map(str, recent)),
        max_age=COOKIE_MAX_AGE,
        httponly=True,
        samesite="Lax",
    )
    return response


# ---------- CRUD книг (адміністратор) ----------

@bp.route("/books/new", methods=["GET", "POST"])
@admin_required
def book_create():
    if request.method == "POST":
        try:
            data = parse_book_data(request.form.to_dict())
            if isbn_taken(data["isbn"]):
                raise ValidationError({"isbn": "Книга з таким ISBN вже існує"})
        except ValidationError as exc:
            return (
                render_template("book_form.html", book=None, errors=exc.errors, values=request.form),
                400,
            )
        book = Book(**data)
        db.session.add(book)
        db.session.commit()
        flash("Книгу додано до каталогу.", "success")
        return redirect(url_for("web.book_detail", book_id=book.id))
    return render_template("book_form.html", book=None, errors={}, values={})


@bp.route("/books/<int:book_id>/edit", methods=["GET", "POST"])
@admin_required
def book_edit(book_id):
    book = db.get_or_404(Book, book_id)
    if request.method == "POST":
        try:
            data = parse_book_data(request.form.to_dict())
            if isbn_taken(data["isbn"], exclude_id=book.id):
                raise ValidationError({"isbn": "Книга з таким ISBN вже існує"})
        except ValidationError as exc:
            return (
                render_template("book_form.html", book=book, errors=exc.errors, values=request.form),
                400,
            )
        for field, value in data.items():
            setattr(book, field, value)
        db.session.commit()
        flash("Зміни збережено.", "success")
        return redirect(url_for("web.book_detail", book_id=book.id))

    values = {
        "title": book.title,
        "author": book.author,
        "isbn": book.isbn,
        "price": book.price,
        "stock": book.stock,
        "description": book.description or "",
    }
    return render_template("book_form.html", book=book, errors={}, values=values)


@bp.route("/books/<int:book_id>/delete", methods=["POST"])
@admin_required
def book_delete(book_id):
    book = db.get_or_404(Book, book_id)
    if book_has_orders(book.id):
        flash("Книгу не можна видалити: вона є в замовленнях.", "danger")
        return redirect(url_for("web.book_detail", book_id=book.id))
    db.session.delete(book)
    db.session.commit()
    flash("Книгу видалено.", "info")
    return redirect(url_for("web.index"))


# ---------- Кошик (зберігається в session) ----------

def _cart():
    return dict(session.get("cart", {}))


@bp.route("/cart")
def cart():
    items = []
    total = Decimal("0.00")
    for book_id, quantity in _cart().items():
        book = db.session.get(Book, int(book_id))
        if book is None:
            continue
        subtotal = Decimal(str(book.price)) * quantity
        items.append({"book": book, "quantity": quantity, "subtotal": subtotal})
        total += subtotal
    return render_template("cart.html", items=items, total=total)


@bp.route("/cart/add/<int:book_id>", methods=["POST"])
def cart_add(book_id):
    book = db.get_or_404(Book, book_id)
    items = _cart()
    key = str(book_id)
    new_qty = items.get(key, 0) + 1
    if new_qty > book.stock:
        flash(f"На складі лише {book.stock} прим. «{book.title}».", "warning")
    else:
        items[key] = new_qty
        session["cart"] = items
        flash(f"«{book.title}» додано до кошика.", "success")
    return redirect(url_for("web.book_detail", book_id=book_id))


@bp.route("/cart/remove/<int:book_id>", methods=["POST"])
def cart_remove(book_id):
    items = _cart()
    items.pop(str(book_id), None)
    session["cart"] = items
    return redirect(url_for("web.cart"))


# ---------- Замовлення ----------

@bp.route("/checkout", methods=["POST"])
@login_required
def checkout():
    items = [(int(k), v) for k, v in _cart().items()]
    try:
        order = create_order(current_user(), items)
    except OrderError as exc:
        flash(str(exc), "danger")
        return redirect(url_for("web.cart"))
    session.pop("cart", None)
    flash(f"Замовлення #{order.id} оформлено.", "success")
    return redirect(url_for("web.order_detail", order_id=order.id))


@bp.route("/orders")
@login_required
def orders():
    user = current_user()
    user_orders = (
        Order.query.filter_by(user_id=user.id).order_by(Order.created_at.desc()).all()
    )
    return render_template("orders.html", orders=user_orders)


@bp.route("/orders/<int:order_id>")
@login_required
def order_detail(order_id):
    order = db.get_or_404(Order, order_id)
    user = current_user()
    if order.user_id != user.id and not user.is_admin:
        abort(403)
    return render_template("order_detail.html", order=order)


# ---------- Автентифікація ----------

@bp.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        email = request.form.get("email", "").strip()
        password = request.form.get("password", "")
        if not username or not email or len(password) < 6:
            flash("Заповніть усі поля; пароль має бути щонайменше 6 символів.", "danger")
            return render_template("register.html", username=username, email=email), 400
        if User.query.filter(or_(User.username == username, User.email == email)).first():
            flash("Користувач із таким логіном або email уже існує.", "danger")
            return render_template("register.html", username=username, email=email), 409
        user = User(username=username, email=email)
        user.set_password(password)
        db.session.add(user)
        db.session.commit()
        flash("Реєстрація успішна. Тепер увійдіть.", "success")
        return redirect(url_for("web.login"))
    return render_template("register.html", username="", email="")


@bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        user = User.query.filter_by(username=username).first()
        if user and user.check_password(request.form.get("password", "")):
            session.permanent = True
            session["user_id"] = user.id
            next_url = request.args.get("next", "")
            if not next_url.startswith("/") or next_url.startswith("//"):
                next_url = url_for("web.index")
            return redirect(next_url)
        flash("Невірний логін або пароль.", "danger")
        return render_template("login.html"), 401
    return render_template("login.html")


@bp.route("/logout", methods=["POST"])
def logout():
    session.pop("user_id", None)
    flash("Ви вийшли з акаунта.", "info")
    return redirect(url_for("web.index"))
