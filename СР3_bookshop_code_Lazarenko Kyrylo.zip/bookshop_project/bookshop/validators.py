from decimal import Decimal, InvalidOperation


class ValidationError(Exception):
    def __init__(self, errors):
        super().__init__("Помилка валідації")
        self.errors = errors


def parse_book_data(data, partial=False):
    """Перевіряє та нормалізує дані книги.

    partial=True дозволяє не передавати окремі поля (для часткового оновлення).
    Повертає словник лише з валідними полями або кидає ValidationError.
    """
    errors = {}
    clean = {}

    def needed(field):
        return (not partial) or (field in data)

    if needed("title"):
        title = str(data.get("title") or "").strip()
        if title:
            clean["title"] = title
        else:
            errors["title"] = "Назва є обов'язковою"

    if needed("author"):
        author = str(data.get("author") or "").strip()
        if author:
            clean["author"] = author
        else:
            errors["author"] = "Автор є обов'язковим"

    if needed("isbn"):
        isbn = str(data.get("isbn") or "").strip()
        if isbn:
            clean["isbn"] = isbn
        else:
            errors["isbn"] = "ISBN є обов'язковим"

    if needed("price"):
        try:
            price = Decimal(str(data.get("price")))
            if price < 0:
                raise ValueError
            clean["price"] = price.quantize(Decimal("0.01"))
        except (InvalidOperation, ValueError, TypeError):
            errors["price"] = "Некоректна ціна"

    if needed("stock"):
        try:
            stock = int(data.get("stock", 0))
            if stock < 0:
                raise ValueError
            clean["stock"] = stock
        except (TypeError, ValueError):
            errors["stock"] = "Некоректна кількість на складі"

    if "description" in data:
        clean["description"] = str(data.get("description") or "").strip()

    if errors:
        raise ValidationError(errors)
    return clean
