from functools import wraps

from flask import abort, flash, jsonify, redirect, request, session, url_for

from .extensions import db
from .models import User


def current_user():
    uid = session.get("user_id")
    return db.session.get(User, uid) if uid else None


def _is_api_request():
    return request.path.startswith("/api/")


def login_required(view):
    @wraps(view)
    def wrapper(*args, **kwargs):
        if current_user() is None:
            if _is_api_request():
                return jsonify(error="Потрібна автентифікація"), 401
            flash("Увійдіть, щоб продовжити.", "warning")
            return redirect(url_for("web.login", next=request.path))
        return view(*args, **kwargs)

    return wrapper


def admin_required(view):
    @wraps(view)
    @login_required
    def wrapper(*args, **kwargs):
        if not current_user().is_admin:
            if _is_api_request():
                return jsonify(error="Доступ заборонено"), 403
            abort(403)
        return view(*args, **kwargs)

    return wrapper
