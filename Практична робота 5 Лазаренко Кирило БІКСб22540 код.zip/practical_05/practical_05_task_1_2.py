# practical_05_task_1_2.py

"""Генератор requirements.txt з перевіркою залежностей.

Запуск:
    python practical_05_task_1_2.py            # створити requirements.txt і перевірити
    python practical_05_task_1_2.py --verify   # лише перевірити існуючий файл
"""


import json
import subprocess
import sys
from importlib import metadata
from pathlib import Path

# Службові пакети, які не потрібно записувати у requirements.txt
SYSTEM_PACKAGES = {'pip', 'setuptools', 'wheel'}


def get_installed_packages() -> list[dict]:
    """Повертає список встановлених пакетів з версіями.

    Returns:
        Список словників {'name': ..., 'version': ...}.
        Порожній список, якщо pip не вдалося запустити.
    """
    result = subprocess.run(
        [sys.executable, '-m', 'pip', 'list', '--format=json'],
        capture_output=True, text=True
    )
    if result.returncode != 0:
        print("Помилка запуску pip:", result.stderr.strip())
        return []

    try:
        data = json.loads(result.stdout)
    except json.JSONDecodeError:
        print("Не вдалося розпарсити вивід pip")
        return []

    packages = [{'name': item['name'], 'version': item['version']} for item in data]
    return sorted(packages, key=lambda pkg: pkg['name'].lower())


def generate_requirements(packages: list[dict], filename: str = 'requirements.txt') -> list[str]:
    """Записує пакети у файл requirements.txt.

    Args:
        packages: список словників з ключами 'name' та 'version'.
        filename: ім'я файлу для запису.

    Returns:
        Список записаних рядків.
    """
    lines = [
        f"{pkg['name']}=={pkg['version']}"
        for pkg in packages
        if pkg['name'].lower() not in SYSTEM_PACKAGES
    ]
    Path(filename).write_text('\n'.join(lines) + '\n', encoding='utf-8')
    return lines


def verify_requirements(filename: str = 'requirements.txt') -> bool:
    """Перевіряє, чи всі пакети з requirements.txt встановлені потрібної версії.

    Args:
        filename: шлях до файлу requirements.txt.

    Returns:
        True, якщо всі залежності задоволені.
    """
    path = Path(filename)
    if not path.exists():
        print(f"Файл {filename} не знайдено. Спочатку створіть його або виконайте pip freeze.")
        return False

    ok = True
    for raw_line in path.read_text(encoding='utf-8').splitlines():
        line = raw_line.strip()
        if not line or line.startswith('#'):
            continue
        if '==' not in line:
            print(f"  ? Пропущено рядок без точної версії: {line}")
            continue

        name, expected = (part.strip() for part in line.split('==', 1))
        try:
            installed = metadata.version(name)
        except metadata.PackageNotFoundError:
            print(f"  ✗ {name}: не встановлено (очікувалась версія {expected})")
            ok = False
            continue

        if installed == expected:
            print(f"  ✓ {name}=={installed}")
        else:
            print(f"  ✗ {name}: встановлено {installed}, очікувалась {expected}")
            ok = False
    return ok


def main():
    # Режим лише перевірки (для другого віртуального середовища)
    if '--verify' in sys.argv:
        ok = verify_requirements()
        print(f"Перевірка залежностей: {'✓ Усе OK' if ok else '✗ Є розбіжності'}")
        return

    packages = get_installed_packages()
    if not packages:
        print("Пакети не отримано, requirements.txt не створено.")
        return

    print(f"Знайдено {len(packages)} встановлених пакетів\n")
    for pkg in packages[:10]:
        print(f"  {pkg['name']}=={pkg['version']}")
    if len(packages) > 10:
        print(f"  ... та ще {len(packages) - 10}")

    lines = generate_requirements(packages)
    print(f"\nФайл requirements.txt створено ({len(lines)} пакетів)")

    ok = verify_requirements()
    print(f"Перевірка залежностей: {'✓ Усе OK' if ok else '✗ Є розбіжності'}")


if __name__ == "__main__":
    main()
