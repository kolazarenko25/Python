# practical_05_task_2_2.py

"""Аналізатор конфігурації Django-проекту.

Файл settings.py не виконується, а розбирається як текст через модуль ast.
Це безпечніше: аналізатор не запускає код проекту.
"""


import ast
import os
import sys

# Людські назви для популярних движків бази даних
DB_NAMES = {
    'sqlite3': 'SQLite',
    'postgresql': 'PostgreSQL',
    'mysql': 'MySQL',
    'oracle': 'Oracle',
}


def _read_settings(settings_path: str):
    """Читає settings.py і повертає (вихідний текст, AST-дерево)."""
    with open(settings_path, encoding='utf-8') as f:
        source = f.read()
    return source, ast.parse(source, filename=settings_path)


def _top_level_assignments(tree: ast.Module) -> dict:
    """Збирає присвоєння верхнього рівня у вигляді {ім'я: вузол значення}."""
    assignments = {}
    for node in tree.body:
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name):
                    assignments[target.id] = node.value
        elif isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name) \
                and node.value is not None:
            assignments[node.target.id] = node.value
    return assignments


def _value(node, source: str, default=None):
    """Повертає Python-значення вузла.

    Якщо вузол не є простим літералом (наприклад, BASE_DIR / 'db.sqlite3'
    або os.environ.get(...)), повертає його текст з коду.
    """
    if node is None:
        return default
    try:
        return ast.literal_eval(node)
    except (ValueError, TypeError):
        return ast.get_source_segment(source, node)


def _database_engine(node, source: str):
    """Знаходить значення ENGINE у DATABASES['default']."""
    if not isinstance(node, ast.Dict):
        return None
    for key, value in zip(node.keys, node.values):
        is_default = isinstance(key, ast.Constant) and key.value == 'default'
        if is_default and isinstance(value, ast.Dict):
            for inner_key, inner_value in zip(value.keys, value.values):
                if isinstance(inner_key, ast.Constant) and inner_key.value == 'ENGINE':
                    return _value(inner_value, source)
    return None


def analyze_settings(settings_path: str) -> dict:
    """Аналізує файл settings.py та повертає ключові параметри.

    Args:
        settings_path: шлях до файлу settings.py.

    Returns:
        Словник з аналізом конфігурації.
    """
    source, tree = _read_settings(settings_path)
    values = _top_level_assignments(tree)

    engine = _database_engine(values.get('DATABASES'), source)
    engine_label = None
    if isinstance(engine, str):
        short_name = engine.rsplit('.', 1)[-1]
        engine_label = f"{DB_NAMES.get(short_name, short_name)} ({engine})"

    return {
        'DEBUG': _value(values.get('DEBUG'), source, default=False),
        'INSTALLED_APPS': _value(values.get('INSTALLED_APPS'), source, default=[]),
        'DATABASES': engine_label or 'не визначено',
        'LANGUAGE_CODE': _value(values.get('LANGUAGE_CODE'), source),
        'TIME_ZONE': _value(values.get('TIME_ZONE'), source),
    }


def check_security(settings_path: str) -> list[str]:
    """Перевіряє базову безпеку конфігурації.

    Args:
        settings_path: шлях до файлу settings.py.

    Returns:
        Список попереджень безпеки.
    """
    source, tree = _read_settings(settings_path)
    values = _top_level_assignments(tree)
    warnings = []

    # Правило 1: DEBUG = True небезпечно для production
    if _value(values.get('DEBUG'), source, default=False) is True:
        warnings.append("DEBUG = True: у production режим налагодження слід вимкнути")

    # Правило 2: SECRET_KEY має братися зі змінної оточення, а не з коду
    secret_node = values.get('SECRET_KEY')
    if secret_node is None:
        warnings.append("SECRET_KEY не задано")
    elif 'os.environ' not in (ast.get_source_segment(source, secret_node) or ''):
        warnings.append("SECRET_KEY захардкоджено в коді (варто брати з os.environ)")

    # Правило 3: ALLOWED_HOSTS має містити дозволені домени
    allowed_hosts = _value(values.get('ALLOWED_HOSTS'), source, default=[])
    if not allowed_hosts:
        warnings.append("ALLOWED_HOSTS порожній: у production сюди слід додати домен сайту")

    return warnings


def main():
    settings_path = 'mysite/mysite/settings.py'
    if not os.path.exists(settings_path):
        print(f"Файл {settings_path} не знайдено")
        sys.exit(1)

    config = analyze_settings(settings_path)
    print("=== Аналіз конфігурації Django ===\n")
    for key, value in config.items():
        print(f"  {key}: {value}")

    print("\n=== Перевірка безпеки ===\n")
    warnings = check_security(settings_path)
    if warnings:
        for warning in warnings:
            print(f"  ⚠ {warning}")
    else:
        print("  Попереджень не знайдено")


if __name__ == "__main__":
    main()
