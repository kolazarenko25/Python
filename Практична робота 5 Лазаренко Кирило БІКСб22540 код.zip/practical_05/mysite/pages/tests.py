"""Тести маршрутів додатка pages. Запуск: python manage.py test"""


from django.test import TestCase


class PagesViewsTests(TestCase):
    """Перевіряє, що всі три сторінки відповідають кодом 200."""

    def test_index_page(self):
        response = self.client.get('/')
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, '<h1>')

    def test_about_page(self):
        response = self.client.get('/about/')
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Практична робота')

    def test_contact_with_name(self):
        response = self.client.get('/contact/', {'name': 'Кирило'})
        self.assertContains(response, 'Вітаємо, Кирило')

    def test_contact_without_name(self):
        response = self.client.get('/contact/')
        self.assertContains(response, 'ваше_ім')
