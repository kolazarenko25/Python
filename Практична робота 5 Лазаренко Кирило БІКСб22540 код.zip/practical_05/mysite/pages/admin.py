"""Реєстрація моделей в адмін-панелі. Моделей поки немає."""


from django.contrib import admin  # noqa: F401
