"""Моделі додатка pages. Для цієї роботи моделі не потрібні."""


from django.db import models  # noqa: F401
