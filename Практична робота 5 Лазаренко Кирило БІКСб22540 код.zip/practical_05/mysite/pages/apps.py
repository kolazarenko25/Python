"""Конфігурація додатка pages."""


from django.apps import AppConfig


class PagesConfig(AppConfig):
    """Конфігурація додатка pages (реєструється у INSTALLED_APPS)."""

    default_auto_field = 'django.db.models.BigAutoField'
    name = 'pages'
