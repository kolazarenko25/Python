"""Views додатка pages."""


from django.http import HttpResponse
from django.utils.html import escape

COURSE_NAME = 'Безпека інформаційних та комунікаційних технологій'
PRACTICAL_NUMBER = 5
STUDENT_NAME = 'Лазаренко Кирило'


def _page(title: str, body: str) -> HttpResponse:
    """Загортає вміст сторінки у базовий HTML-каркас."""
    html = f"""<!doctype html>
<html lang="uk">
<head>
  <meta charset="utf-8">
  <title>{title}</title>
</head>
<body>
  {body}
</body>
</html>"""
    return HttpResponse(html)


def index(request):
    """Головна сторінка."""
    body = """
    <h1>Ласкаво просимо до Django-проекту!</h1>
    <p>Це головна сторінка додатка pages, створеного у межах практичної роботи №5.</p>
    <ul>
      <li><a href="/">Головна сторінка</a></li>
      <li><a href="/about/">Про проект</a></li>
      <li><a href="/contact/?name=Кирило">Контакти з параметром name</a></li>
    </ul>
    """
    return _page('Головна', body)


def about(request):
    """Сторінка 'Про проект'."""
    body = f"""
    <h1>Про проект</h1>
    <p>Курс: {escape(COURSE_NAME)}</p>
    <p>Практична робота №{PRACTICAL_NUMBER}</p>
    <p>Студент: {escape(STUDENT_NAME)}</p>
    """
    return _page('Про проект', body)


def contact(request):
    """Контактна сторінка з параметрами запиту (?name=...)."""
    name = request.GET.get('name')
    if name:
        text = f"Вітаємо, {escape(name)}! Дякуємо, що звернулися до нас."
    else:
        text = "Додайте параметр ?name=ваше_ім'я до адреси, щоб побачити персональне привітання."
    body = f"<h1>Контакти</h1><p>{text}</p>"
    return _page('Контакти', body)
