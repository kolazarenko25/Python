"""
ASGI-конфігурація проекту mysite.

Надає об'єкт application для ASGI-серверів (uvicorn, daphne тощо).
Документація: https://docs.djangoproject.com/en/5.2/howto/deployment/asgi/
"""


import os

from django.core.asgi import get_asgi_application

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'mysite.settings')

application = get_asgi_application()
