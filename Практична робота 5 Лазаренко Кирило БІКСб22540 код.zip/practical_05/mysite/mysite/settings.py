"""
Налаштування Django-проекту mysite.

Документація: https://docs.djangoproject.com/en/5.2/topics/settings/
"""


import os
from pathlib import Path

# Корінь проекту (каталог, де лежить manage.py)
BASE_DIR = Path(__file__).resolve().parent.parent

# Секретний ключ беремо зі змінної оточення.
# Значення після коми використовується лише для локальної розробки.
SECRET_KEY = os.environ.get(
    'DJANGO_SECRET_KEY',
    'django-insecure-local-dev-only-change-me',
)

# У production має бути False. Для навчальної роботи залишено True.
DEBUG = True

# Дозволені доменні імена сайту. Порожній список при DEBUG=True
# дозволяє доступ лише з localhost; у production сюди додають домен.
ALLOWED_HOSTS = []


# Додатки, що підключаються до проекту (пояснення — у звіті)
INSTALLED_APPS = [
    'django.contrib.admin',         # адміністративна панель за адресою /admin/
    'django.contrib.auth',          # користувачі, групи, автентифікація
    'django.contrib.contenttypes',  # внутрішній облік моделей (потрібен для auth і admin)
    'django.contrib.sessions',      # сесії користувачів
    'django.contrib.messages',      # одноразові повідомлення для користувача
    'django.contrib.staticfiles',   # збір і обслуговування статичних файлів
    'pages',                        # наш додаток: головна, про проєкт, контакт
]

# Проміжне ПЗ: ланцюжок обробників, через які проходить кожен запит і відповідь
MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

ROOT_URLCONF = 'mysite.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [],
        # APP_DIRS=True: шукати шаблони у каталозі templates/ кожного додатка
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

WSGI_APPLICATION = 'mysite.wsgi.application'


# База даних: SQLite — файл db.sqlite3 у корені проекту
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / 'db.sqlite3',
    }
}


# Валідатори складності паролів
AUTH_PASSWORD_VALIDATORS = [
    {'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator'},
    {'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator'},
    {'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator'},
    {'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator'},
]


# Локалізація
LANGUAGE_CODE = 'uk'          # українська мова інтерфейсу
TIME_ZONE = 'Europe/Kyiv'     # часовий пояс України
USE_I18N = True
USE_TZ = True


# Статичні файли (CSS, JS, зображення)
STATIC_URL = 'static/'

DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'
