"""Кореневі URL-маршрути проекту mysite."""


from django.contrib import admin
from django.urls import path, include


urlpatterns = [
    path('admin/', admin.site.urls),
    # Маршрути додатка pages підключаються до кореня сайту
    path('', include('pages.urls')),
]
