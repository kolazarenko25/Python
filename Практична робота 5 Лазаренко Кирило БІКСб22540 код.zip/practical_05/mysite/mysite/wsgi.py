"""
WSGI-конфігурація проекту mysite.

Надає об'єкт application для WSGI-серверів (gunicorn, uWSGI тощо).
Документація: https://docs.djangoproject.com/en/5.2/howto/deployment/wsgi/
"""


import os

from django.core.wsgi import get_wsgi_application

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'mysite.settings')

application = get_wsgi_application()
