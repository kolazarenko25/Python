#!/usr/bin/env python
"""Утиліта командного рядка Django для проекту mysite."""


import os
import sys


def main():
    """Запускає адміністративні команди Django (runserver, migrate, startapp тощо)."""
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'mysite.settings')
    try:
        from django.core.management import execute_from_command_line
    except ImportError as exc:
        raise ImportError(
            "Не вдалося імпортувати Django. Перевірте, чи встановлено його "
            "та чи активовано віртуальне середовище."
        ) from exc
    execute_from_command_line(sys.argv)


if __name__ == '__main__':
    main()
