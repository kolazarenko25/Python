# myflaskapp/app.py

"""Головний файл Flask-додатка."""


from html import escape
from importlib import metadata

from flask import Flask, jsonify, request

from config import config_by_name


def create_app(config_name: str = 'default') -> Flask:
    """Фабрика додатка Flask (патерн Application Factory).

    Args:
        config_name: ім'я конфігурації ('development', 'production').

    Returns:
        Налаштований екземпляр Flask.
    """
    app = Flask(__name__)

    # Завантажуємо клас конфігурації з config_by_name
    app.config.from_object(config_by_name[config_name])

    if config_name == 'production' and not app.config.get('SECRET_KEY'):
        raise RuntimeError("Для production потрібно задати змінну оточення SECRET_KEY")

    register_routes(app)
    return app


def _page(title: str, body: str) -> str:
    """Загортає вміст сторінки у базовий HTML-каркас."""
    return f"""<!doctype html>
<html lang="uk">
<head>
  <meta charset="utf-8">
  <title>{title}</title>
  <link rel="stylesheet" href="/static/style.css">
</head>
<body>
  {body}
</body>
</html>"""


def register_routes(app: Flask):
    """Реєструє маршрути додатка."""

    @app.route('/')
    def index():
        """Головна сторінка."""
        body = """
        <h1>Привіт із Flask!</h1>
        <p>Це головна сторінка додатка, створеного за патерном Application Factory.</p>
        <nav>
          <a href="/about">Про додаток</a> |
          <a href="/api/info">Інформація у JSON</a> |
          <a href="/greet/Студент">Привітання</a>
        </nav>
        """
        return _page('Головна', body)

    @app.route('/about')
    def about():
        """Сторінка 'Про додаток'."""
        body = """
        <h1>Про додаток</h1>
        <p>Практична робота №5: ініціалізація та конфігурація веб-проектів.</p>
        <p>Студент: Лазаренко Кирило, група БІКСб22540.</p>
        <p>Фреймворк: Flask, структура з каталогами templates/ та static/.</p>
        """
        return _page('Про додаток', body)

    @app.route('/api/info')
    def api_info():
        """API-ендпоінт з інформацією у форматі JSON."""
        routes = sorted(
            rule.rule for rule in app.url_map.iter_rules()
            if rule.endpoint != 'static'
        )
        return jsonify({
            'framework': 'Flask',
            # Атрибут flask.__version__ застарів, тому версію беремо з метаданих
            'version': metadata.version('flask'),
            'debug': app.debug,
            'routes': routes,
        })

    @app.route('/greet')
    @app.route('/greet/<name>')
    def greet(name=None):
        """Маршрут з динамічним параметром у шляху або query-параметром.

        Приклади:
            /greet/Кирило       -> name з URL
            /greet?name=Кирило  -> name з query-рядка
            /greet              -> 'Гість'
        """
        if not name:
            name = request.args.get('name') or 'Гість'
        # escape() захищає від впровадження HTML через параметр запиту
        body = f"<h1>Привіт, {escape(name)}!</h1><p><a href=\"/\">На головну</a></p>"
        return _page('Привітання', body)


if __name__ == '__main__':
    application = create_app('development')
    application.run(debug=True, port=5000)
