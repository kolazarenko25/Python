# myflaskapp/config.py

"""Конфігурація Flask-додатка."""


import os


class Config:
    """Базова конфігурація."""

    # Ключ для підпису сесій і CSRF-токенів.
    # Беремо зі змінної оточення; значення після коми — лише для розробки.
    SECRET_KEY = os.environ.get('SECRET_KEY', 'dev-only-secret-key-change-me')
    DEBUG = False
    TESTING = False


class DevelopmentConfig(Config):
    """Конфігурація для розробки."""

    DEBUG = True


class ProductionConfig(Config):
    """Конфігурація для production."""

    # У production ключ обов'язково має бути заданий у змінній оточення.
    # Перевірка виконується у create_app().
    SECRET_KEY = os.environ.get('SECRET_KEY')
    DEBUG = False


config_by_name = {
    'development': DevelopmentConfig,
    'production': ProductionConfig,
    'default': DevelopmentConfig,
}
