# practical_05_task_3_2.py

"""Порівняльний аналіз структури Django та Flask проектів."""


import os

# Службові елементи, які не є частиною структури проекту
IGNORED_DIRS = {'__pycache__', 'venv', '.venv', '.git'}
IGNORED_FILES = {'db.sqlite3'}
IGNORED_SUFFIXES = ('.pyc',)


def is_ignored(name: str, is_dir: bool) -> bool:
    """Перевіряє, чи слід пропустити файл або каталог."""
    if is_dir:
        return name in IGNORED_DIRS
    return name in IGNORED_FILES or name.endswith(IGNORED_SUFFIXES)


def scan_directory(path: str, prefix: str = '') -> list[str]:
    """Рекурсивно сканує каталог та повертає дерево файлів.

    Args:
        path: шлях до каталогу.
        prefix: відступ для форматування дерева.

    Returns:
        Список рядків зі структурою каталогу.
    """
    tree = []
    entries = []
    for name in sorted(os.listdir(path), key=str.lower):
        full_path = os.path.join(path, name)
        if not is_ignored(name, os.path.isdir(full_path)):
            entries.append((name, full_path))

    for index, (name, full_path) in enumerate(entries):
        is_last = index == len(entries) - 1
        branch = '└── ' if is_last else '├── '

        if os.path.isdir(full_path):
            tree.append(f"{prefix}{branch}{name}/")
            child_prefix = prefix + ('    ' if is_last else '│   ')
            tree.extend(scan_directory(full_path, child_prefix))
        else:
            tree.append(f"{prefix}{branch}{name}")
    return tree


def analyze_project(path: str) -> dict:
    """Аналізує проект та збирає статистику.

    Args:
        path: кореневий каталог проекту.

    Returns:
        Словник зі статистикою: кількість файлів .py, .html, .css,
        загальний розмір, список каталогів.
    """
    stats = {
        'py_files': 0,
        'html_files': 0,
        'css_files': 0,
        'total_files': 0,
        'total_size': 0,
        'directories': [],
    }

    for root, dirs, files in os.walk(path):
        # Змінюємо dirs на місці, щоб os.walk не заходив у службові каталоги
        dirs[:] = [d for d in dirs if not is_ignored(d, True)]

        relative_root = os.path.relpath(root, path)
        if relative_root != '.':
            stats['directories'].append(relative_root.replace(os.sep, '/'))

        for file_name in files:
            if is_ignored(file_name, False):
                continue

            full_path = os.path.join(root, file_name)
            stats['total_files'] += 1
            stats['total_size'] += os.path.getsize(full_path)

            extension = os.path.splitext(file_name)[1].lower()
            if extension == '.py':
                stats['py_files'] += 1
            elif extension == '.html':
                stats['html_files'] += 1
            elif extension == '.css':
                stats['css_files'] += 1

    return stats


def compare_projects(django_path: str, flask_path: str):
    """Порівнює два проекти та виводить таблицю відмінностей.

    Args:
        django_path: шлях до Django-проекту.
        flask_path: шлях до Flask-проекту.
    """
    print("=" * 60)
    print("ПОРІВНЯННЯ СТРУКТУРИ ПРОЕКТІВ")
    print("=" * 60)

    # Django
    print(f"\n--- Django ({django_path}) ---")
    for line in scan_directory(django_path):
        print(line)
    django_stats = analyze_project(django_path)

    # Flask
    print(f"\n--- Flask ({flask_path}) ---")
    for line in scan_directory(flask_path):
        print(line)
    flask_stats = analyze_project(flask_path)

    # Порівняльна таблиця
    rows = [
        ('Файли .py', django_stats['py_files'], flask_stats['py_files']),
        ('Файли .html', django_stats['html_files'], flask_stats['html_files']),
        ('Файли .css', django_stats['css_files'], flask_stats['css_files']),
        ('Файли всього', django_stats['total_files'], flask_stats['total_files']),
        ('Каталоги', len(django_stats['directories']), len(flask_stats['directories'])),
        ('Розмір (байт)', django_stats['total_size'], flask_stats['total_size']),
    ]

    print("\n--- Порівняльна таблиця ---\n")
    print(f"| {'Характеристика':<16} | {'Django':>8} | {'Flask':>8} |")
    print(f"|{'-' * 18}|{'-' * 10}|{'-' * 10}|")
    for label, django_value, flask_value in rows:
        print(f"| {label:<16} | {django_value:>8} | {flask_value:>8} |")


def main():
    django_path = 'mysite'
    flask_path = 'myflaskapp'

    for path in [django_path, flask_path]:
        if not os.path.isdir(path):
            print(f"Каталог '{path}' не знайдено. Спершу виконайте попередні завдання.")
            return

    compare_projects(django_path, flask_path)


if __name__ == "__main__":
    main()
