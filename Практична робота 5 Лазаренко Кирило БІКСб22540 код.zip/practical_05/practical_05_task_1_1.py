# practical_05_task_1_1.py

"""Скрипт перевірки середовища розробки."""


import importlib
import sys
from importlib import metadata

MIN_PYTHON = (3, 10)


def check_python_version() -> bool:
    """Перевіряє версію Python (потрібна >= 3.10).

    Returns:
        True, якщо версія Python достатня.
    """
    version = sys.version_info
    print(f"Python {version.major}.{version.minor}.{version.micro}")

    if (version.major, version.minor) < MIN_PYTHON:
        print(f"  ⚠ Потрібна версія Python {MIN_PYTHON[0]}.{MIN_PYTHON[1]} або новіша")
        return False
    return True


def check_virtualenv() -> bool:
    """Перевіряє, чи запущено скрипт у віртуальному середовищі.

    Усередині venv sys.prefix відрізняється від sys.base_prefix.

    Returns:
        True, якщо віртуальне середовище активне.
    """
    in_venv = sys.prefix != sys.base_prefix
    print(f"Віртуальне середовище активне: {'так' if in_venv else 'ні'}")
    print(f"Шлях до інтерпретатора: {sys.executable}")
    return in_venv


def check_package(package_name: str) -> bool:
    """Перевіряє, чи встановлено пакет, і виводить його версію.

    Args:
        package_name: назва пакета для перевірки.

    Returns:
        True, якщо пакет встановлено.
    """
    try:
        module = importlib.import_module(package_name)
    except ImportError:
        print(f"  {package_name}: НЕ ВСТАНОВЛЕНО ✗")
        return False

    try:
        # Версію беремо з метаданих пакета: атрибут __version__ у Flask
        # застарів і буде видалений у Flask 3.2
        version = metadata.version(package_name)
    except metadata.PackageNotFoundError:
        version = getattr(module, '__version__', 'невідома')

    print(f"  {package_name}: {version} ✓")
    return True


def main():
    python_ok = check_python_version()
    check_virtualenv()

    print("\nВстановлені пакети:")
    packages = ['django', 'flask']
    results = {pkg: check_package(pkg) for pkg in packages}

    installed = [pkg for pkg, ok in results.items() if ok]
    missing = [pkg for pkg, ok in results.items() if not ok]

    print("\nПідсумок:")
    print(f"  встановлено: {len(installed)} з {len(packages)}")
    print(f"  відсутні: {len(missing)}")

    if missing:
        print(f"\nДля встановлення виконайте: pip install {' '.join(missing)}")
    if not python_ok:
        print("\nОновіть Python до версії 3.10 або новіше.")


if __name__ == "__main__":
    main()
